-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 02, 2021 at 12:17 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bitm36`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(11) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `brand`, `created_at`) VALUES
(10, 'apara', '2020-11-03 21:16:15'),
(11, 'pran', '2020-10-23 05:37:03'),
(12, 'danish', '2020-10-23 05:37:15'),
(13, 'radhuni', '2020-10-23 05:37:22'),
(15, 'lufenow', '2020-11-03 21:15:35');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category`, `created_at`) VALUES
(8, 'electronic accessories', '2020-12-17 02:50:01'),
(9, 'tv & home appliances', '2020-12-17 02:53:26'),
(10, 'health & beauty', '2020-12-17 02:53:46'),
(11, 'babies & toys', '2020-12-17 02:53:57'),
(12, 'babies & toys', '2020-12-17 02:54:07'),
(13, 'home & lifestyle', '2020-12-17 02:54:19'),
(14, 'automotive & motorbike', '2020-12-17 02:57:32'),
(15, 'womens fashion', '2020-12-17 02:57:56'),
(16, 'mens fashion', '2020-12-17 02:58:10'),
(17, 'nursery & plant', '2020-12-17 02:58:20'),
(18, 'watches & accessories', '2020-12-17 02:58:30'),
(19, 'sports & outdoor', '2020-12-17 02:58:39'),
(20, 'nursery accessories', '2020-12-17 02:58:49');

-- --------------------------------------------------------

--
-- Table structure for table `colors`
--

CREATE TABLE `colors` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `colors`
--

INSERT INTO `colors` (`id`, `name`) VALUES
(1, 'red'),
(2, 'green'),
(3, 'blue'),
(4, 'pink'),
(5, 'aqua'),
(6, 'orange'),
(7, 'black');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(11) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `order_status` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `product_id`, `qty`, `price`, `supplier_id`, `address`, `order_status`, `created_at`) VALUES
(1, '0', 0, 2, 0, 123, '', '', '2020-11-03 13:07:57'),
(2, '0', 0, 2, 900, 123, '', '', '2020-11-03 13:07:57'),
(3, '0', 0, 1, 450, 123, '', '', '2020-11-03 13:07:57'),
(4, '0', 0, 3, 900, 123, '', '', '2020-11-03 13:07:57'),
(5, '0', 0, 1, 450, 123, '', '', '2020-11-03 13:07:57'),
(6, '0', 0, 2, 900, 123, '', '', '2020-11-03 13:07:57'),
(7, '0', 0, 6, 1800, 123, '', '', '2020-11-03 13:07:57'),
(11, '2147483647', 0, 2, 900, 123, '', '', '2020-11-03 13:07:57'),
(12, '2147483647', 0, 2, 1800, 123, '', '', '2020-11-03 13:07:57'),
(13, '2147483647', 0, 1, 450, 123, '', '', '2020-11-03 13:07:57'),
(14, '2147483647', 0, 1, 900, 123, '', '', '2020-11-03 13:07:57'),
(15, '2147483647', 0, 2, 1800, 123, '', '', '2020-11-03 13:07:57'),
(16, '2147483647', 0, 3, 450, 123, '', '', '2020-11-03 13:07:57'),
(17, '2147483647', 0, 1, 1800, 123, '', '', '2020-11-03 13:07:57'),
(18, '2147483647', 0, 1, 900, 123, '', '', '2020-11-03 13:07:57'),
(19, '2147483647', 0, 1, 1800, 123, '', '', '2020-11-03 13:07:57'),
(20, '2147483647', 0, 2, 1800, 123, '', '', '2020-11-03 13:07:57'),
(21, '2147483647', 0, 2, 1800, 123, '', '', '2020-11-03 13:07:57'),
(22, '2147483647', 0, 2, 1800, 123, '', '', '2020-11-03 13:07:57'),
(23, '2147483647', 0, 2, 900, 123, '', '', '2020-11-03 13:07:57'),
(24, '2147483647', 0, 2, 1800, 123, '', '', '2020-11-03 13:07:57'),
(25, '2147483647', 0, 3, 900, 123, '', '', '2020-11-03 13:07:57');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `sku` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `buying_price` int(11) NOT NULL,
  `selling_price` int(11) NOT NULL,
  `discount` int(11) NOT NULL,
  `vat` int(11) NOT NULL,
  `size` varchar(20) NOT NULL,
  `color` varchar(200) NOT NULL,
  `stock_qty` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `sub_category_id` int(11) NOT NULL,
  `brand_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `sku`, `description`, `buying_price`, `selling_price`, `discount`, `vat`, `size`, `color`, `stock_qty`, `category_id`, `sub_category_id`, `brand_id`, `supplier_id`, `created_at`) VALUES
(42, 'cotton t-shirt for men', 'pts - 15', 'fabrics material:single nit cotton\r\nmain material: 100% cotton\r\nsleeve: short sleeve\r\nwash & care: machine wash\r\nfit: slim -fit\r\ngsm:170\r\nsizes:\r\n• s (chest 34,long 26 )\r\n• m (chest 36,length 27)\r\n• l (chest 38,length 28)\r\n• xl (chest 40,length 29)\r\n• xxl(chest 42,length 30)', 150, 95, 62, 15, '[\"11\",\"10\",\"9\",\"8\"]', '[\"3\",\"1\"]', 1000, 16, 13, 10, 28, '2020-12-18 22:35:32'),
(43, 'white cotton heart beat t-shirt for men', 'apt-565', '    product type: t-shirt\r\n    color: white\r\n    main material: cotton\r\n    gender: men\r\n    style: casual', 230, 99, 76, 15, '[\"11\",\"10\",\"9\",\"8\"]', '[\"7\"]', 1000, 16, 13, 10, 28, '2020-12-19 20:57:45'),
(44, 'pack of 2 black cotton t-shirts for couple', 'apt-175', '    product type: t-shirt\r\n    color: black\r\n    main material: cotton\r\n    gender: unisex', 499, 300, 70, 15, '[\"11\",\"10\",\"9\"]', '[\"7\"]', 1000, 16, 13, 10, 28, '2020-12-19 21:04:51'),
(45, 'phillies hoodie for men', 'apt-670', '    product type: hoodie\r\n    color: deep green\r\n    main material: phillies\r\n    gender: men\r\n    style: casual', 1000, 450, 55, 15, '[\"12\",\"11\",\"10\",\"9\",', '[\"4\",\"2\"]', 1000, 15, 18, 10, 28, '2020-12-20 23:09:02'),
(46, 'ash phillies hoodie for men', 'apt-579', '    product type: hoodie\r\n    color: ash\r\n    main material: phillies\r\n    gender: men\r\n    style: casual', 1000, 450, 55, 15, '[\"11\",\"10\",\"9\",\"8\"]', '[\"7\"]', 1000, 15, 18, 10, 28, '2020-12-20 23:16:32'),
(47, 'mens fashionable full sleeves hooddie', 'apt-897', '    size:\r\n    m(chest=40 ,long-26.50)\r\n    l (chest=44 ,long-27.50)\r\n    xl(chest=46,long-28.5 )\r\n    xxl(chest=50,long-29)\r\n    3xl(chest=53,long-29.5 )\r\n    quality: export quality\r\n    fabrics : phillies\r\n    gsm:220 to 260 around\r\n    manufacture:bangladesh\r\n    main material: 100% cotton\r\n    wash & care: machine wash\r\n    fit: western fashionable medium slim -fit\r\n    sleeve : full sleeve\r\n    size can be 0.5 inch +/- ( plus minues ) due to manufacture tolerate\r\n    product color may slig', 1200, 450, 62, 15, '[\"11\",\"10\",\"9\",\"8\"]', '[\"7\",\"3\"]', 1000, 15, 18, 10, 28, '2020-12-20 23:36:17'),
(48, 'independence day special (4 plants pack)', 'plp1', 'this pack contains 4 air purifiers plants in attractive colorful pots + pebbles. get the freedom from pollution and breathe healthy air with these plants around you.', 1800, 1000, 40, 15, '[\"5\",\"4\",\"3\"]', '[\"2\",\"1\"]', 500, 17, 16, 13, 28, '2020-12-21 03:59:14'),
(49, '5 best indoor plants pack ', 'plp-2', 'this plants pack contains amazing 5 houseplants + 5 pots. surround your home with these best pollution killer plants for a clean and healthy environment.', 1980, 1287, 35, 15, '[\"4\",\"3\",\"1\"]', '[\"7\",\"2\"]', 500, 17, 16, 13, 28, '2020-12-21 04:02:09'),
(50, 'set of 3 outdoor flowering plants for beautiful garden ', 'plp-3', 'this pack contains 3 beautiful flowers along with blue color plastic pot and plate with decorative pebbles.', 1340, 938, 30, 15, '[\"4\",\"2\",\"1\"]', '[\"4\",\"3\",\"2\"]', 500, 17, 16, 13, 28, '2020-12-21 04:04:19');

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `status` varchar(200) NOT NULL,
  `image_name` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `status`, `image_name`) VALUES
(64, 42, '1', '2311578066683b6a55da4300dcc397c7d01cfad31.jpg'),
(65, 42, '2', '120286216776478994227b695d5c2056d9f156847ad9e50f9f.jpg'),
(66, 43, '1', '9301508344f83edc8ca39c47faad1df4e1c04d1f9.jpg'),
(67, 43, '2', '545283464120705515a0b9c3147b410d6ddb4b108579bb0c3b.jpg_340x340q90.jpg'),
(68, 44, '1', '54980599738cb8ad3b013d57930ec06f667e1b9f.jpg'),
(69, 44, '2', '677144035120705515a0b9c3147b410d6ddb4b108579bb0c3b.jpg_340x340q90.jpg'),
(70, 45, '1', '380132367be5ea851050c876b9ea740626d021352.jpg'),
(71, 45, '2', '5253974555753798c00319cd2e1db9ee337da919d.jpg'),
(72, 46, '1', '9336122401b12a42bdcd59a0178927c8c867b6030.jpg'),
(73, 46, '2', '524046368da1b4813bed3d166974b3dcf767e2132.jpg'),
(74, 47, '1', '36311832ac53e6522d9322cd9852287cae3287d.jpg'),
(75, 47, '2', '6017427145bb22b313f8859c1fe852f40132b4f2b.jpg'),
(76, 48, '1', '244542550nurserylive-combo-packs-plants-independence-day-special-4-plants-pack-16968950972556_520x520.webp'),
(77, 48, '2', '262660424nurserylive-combo-packs-plants-independence-day-special-4-plants-pack-16968950939788_520x520.webp'),
(78, 49, '1', '672376360nurserylive-combo-packs-plants-5-best-indoor-plants-pack-16968508997772_520x520.webp'),
(79, 49, '2', '396240743nurserylive-combo-packs-plants-5-best-indoor-plants-pack-16968508997772_520x520.webp'),
(80, 50, '1', '168597080nurserylive-combo-packs-plants-set-of-3-outdoor-flowering-plants-for-beautiful-garden-16969318301836_520x520.webp'),
(81, 50, '2', '803784243nurserylive-combo-packs-plants-set-of-3-outdoor-flowering-plants-for-beautiful-garden-16969318301836_520x520.webp');

-- --------------------------------------------------------

--
-- Table structure for table `rolls`
--

CREATE TABLE `rolls` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rolls`
--

INSERT INTO `rolls` (`id`, `name`) VALUES
(1, 'Admin'),
(2, 'Supplier'),
(3, 'User');

-- --------------------------------------------------------

--
-- Table structure for table `sizes`
--

CREATE TABLE `sizes` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sizes`
--

INSERT INTO `sizes` (`id`, `name`) VALUES
(1, '50g'),
(2, '100g'),
(3, '250g'),
(4, '500g'),
(5, '1 kg'),
(6, 'xs'),
(7, 'sm'),
(8, 'm'),
(9, 'l'),
(10, 'xl'),
(11, 'xxl'),
(12, 'xxxl');

-- --------------------------------------------------------

--
-- Table structure for table `sub_categories`
--

CREATE TABLE `sub_categories` (
  `id` int(11) NOT NULL,
  `subcategory` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sub_categories`
--

INSERT INTO `sub_categories` (`id`, `subcategory`, `created_at`) VALUES
(11, 'spices', '2020-10-23 03:41:52'),
(12, 'kitchen item', '2020-10-23 05:37:58'),
(13, 't-shirt', '2020-11-03 21:17:53'),
(15, 'frozen item', '2020-10-23 05:38:46'),
(16, 'vegetable ', '2020-10-23 05:38:55'),
(17, 'fish', '2020-10-23 05:38:59'),
(18, 'home made', '2020-10-25 22:54:30'),
(19, '3pcs', '2020-11-03 21:17:07');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_payment`
--

CREATE TABLE `tbl_payment` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `item_number` varchar(255) NOT NULL,
  `amount` int(11) NOT NULL,
  `currency_code` varchar(20) NOT NULL,
  `txn_id` varchar(255) NOT NULL,
  `payment_status` varchar(255) NOT NULL,
  `payment_response` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_payment`
--

INSERT INTO `tbl_payment` (`id`, `email`, `item_number`, `amount`, `currency_code`, `txn_id`, `payment_status`, `payment_response`, `created_at`) VALUES
(1, '0', '0', 1800, '', '0', '0', '0', '2020-11-03 08:43:57'),
(2, '0', '0', 2250, '', '0', '0', '0', '2020-11-03 08:49:36'),
(3, '0', '0', 3960, '', '0', '0', '0', '2020-11-03 09:09:54'),
(4, '0', '0', 10800, '', '0', '0', '0', '2020-11-03 09:14:50'),
(5, '0', '0', 0, '', '0', '0', '0', '0000-00-00 00:00:00'),
(6, '0', '0', 10800, '', '0', '0', '0', '2020-11-03 09:30:21'),
(7, '0', '0', 10800, '', '0', '0', '0', '2020-11-03 09:31:25'),
(8, '0', '0', 13950, '', '0', '0', '0', '2020-11-03 09:46:13'),
(9, '0', '2147483647', 6750, '', '0', '0', '0', '2020-11-03 10:35:56'),
(10, '0', '2147483647', 3465, '', '0', '0', '0', '2020-11-03 10:58:32'),
(11, '0', '2147483647', 1800, 'usd', '0', '0', '0', '2020-11-03 11:13:05'),
(12, '0', '2147483647', 900, 'usd', '0', '0', '0', '2020-11-03 11:16:33'),
(13, '0', '2147483647', 3600, 'usd', '0', '0', '0', '2020-11-03 11:24:04'),
(14, '0', '2147483647', 3600, 'usd', '0', '0', '0', '2020-11-03 11:28:08'),
(15, '0', '2147483647', 5400, 'bdt', '0', '0', '0', '2020-11-03 12:29:01'),
(16, 'fourgeek4u@gmail.com', '11345076527', 6300, 'bdt', 'txn_1HjOnSJhvdfPu4RwbTiu2sNh', 'succeeded', '{\"id\":\"ch_1HjOnRJhvdfPu4Rw2vWNqC5O\",\"object\":\"charge\",\"amount\":630000,\"amount_captured\":630000,\"amount_refunded\":0,\"application\":null,\"application_fee\":null,\"application_fee_amount\":null,\"balance_transaction\":\"txn_1HjOnSJhvdfPu4RwbTiu2sNh\",\"billing_detail', '2020-11-03 12:39:34'),
(17, 'wer@fg.fg', '18880105520', 6300, 'bdt', 'txn_1Hjem6JhvdfPu4RwgqZzY4Lz', 'succeeded', '{\"id\":\"ch_1Hjem6JhvdfPu4Rw5DwH4j3s\",\"object\":\"charge\",\"amount\":630000,\"amount_captured\":630000,\"amount_refunded\":0,\"application\":null,\"application_fee\":null,\"application_fee_amount\":null,\"balance_transaction\":\"txn_1Hjem6JhvdfPu4RwgqZzY4Lz\",\"billing_detail', '2020-11-04 05:43:16'),
(18, 'amar@gmail.com', '12560970476', 6300, 'bdt', 'txn_1HjesJJhvdfPu4Rw1poCyOqp', 'succeeded', '{\"id\":\"ch_1HjesJJhvdfPu4Rw7Exhr4Kn\",\"object\":\"charge\",\"amount\":630000,\"amount_captured\":630000,\"amount_refunded\":0,\"application\":null,\"application_fee\":null,\"application_fee_amount\":null,\"balance_transaction\":\"txn_1HjesJJhvdfPu4Rw1poCyOqp\",\"billing_detail', '2020-11-04 05:49:40'),
(19, 'amar@gmail.com', '17537698911', 6300, 'bdt', 'txn_1HjettJhvdfPu4RwUChSeCkn', 'succeeded', '{\"id\":\"ch_1HjettJhvdfPu4Rw1SUChFGG\",\"object\":\"charge\",\"amount\":630000,\"amount_captured\":630000,\"amount_refunded\":0,\"application\":null,\"application_fee\":null,\"application_fee_amount\":null,\"balance_transaction\":\"txn_1HjettJhvdfPu4RwUChSeCkn\",\"billing_detail', '2020-11-04 05:51:18');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(50) NOT NULL,
  `passwords` varchar(200) NOT NULL,
  `phone` int(11) NOT NULL,
  `address` varchar(500) NOT NULL,
  `status` varchar(20) NOT NULL,
  `role` int(11) NOT NULL,
  `email_verified` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `passwords`, `phone`, `address`, `status`, `role`, `email_verified`, `created_at`) VALUES
(21, 'imran', 'imran@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 1676823331, 'khilgaon', '1', 3, '0', '2020-11-03 21:14:37'),
(27, 'supper admin', 'supper@admin.com', 'e10adc3949ba59abbe56e057f20f883e', 1676823331, 'dhaka', '1', 1, '0', '2020-11-03 21:10:17'),
(28, 'lufenow', 'lufenowall@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 1952526487, 'narinda', '1', 2, '0', '2020-11-03 21:12:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `colors`
--
ALTER TABLE `colors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rolls`
--
ALTER TABLE `rolls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sizes`
--
ALTER TABLE `sizes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_categories`
--
ALTER TABLE `sub_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `colors`
--
ALTER TABLE `colors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `rolls`
--
ALTER TABLE `rolls`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sizes`
--
ALTER TABLE `sizes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `sub_categories`
--
ALTER TABLE `sub_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tbl_payment`
--
ALTER TABLE `tbl_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
