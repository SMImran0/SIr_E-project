<?php
  
  class Database{
    public $DBHOST ="localhost";
    public $DBNAME ="bitm36";
    public $DBUSER ="root";
    public $DBPASSWORD ="";
}

?>