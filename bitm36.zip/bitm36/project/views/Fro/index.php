<?php
  if(!isset($_SESSION)){
    session_start();
  }

  include($_SERVER['DOCUMENT_ROOT'].'/bitm36/project/app/controllers/admin/ProductController.php');
  //include($_SERVER['DOCUMENT_ROOT'].'/bitm36/project/app/controllers/CategoryController.php');
  include($_SERVER['DOCUMENT_ROOT'].'/bitm36/project/app/helper/GetCategory.php');        
  include($_SERVER['DOCUMENT_ROOT'].'/bitm36/project/app/helper/ProductImage.php');
?>
<!DOCTYPE html>
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->

<head>
  <!-- =====  BASIC PAGE NEEDS  ===== -->
  <meta charset="utf-8">
  <title>HealthCare</title>
  <!-- =====  SEO MATE  ===== -->
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="distribution" content="global">
  <meta name="revisit-after" content="2 Days">
  <meta name="robots" content="ALL">
  <meta name="rating" content="8 YEARS">
  <meta name="Language" content="en-us">
  <meta name="GOOGLEBOT" content="NOARCHIVE">
  <!-- =====  MOBILE SPECIFICATION  ===== -->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta name="viewport" content="width=device-width">
  <!-- =====  CSS  ===== -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/ionicons.min.css" />
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/css.css">
  <link rel="stylesheet" type="text/css" href="css/magnific-popup.css">
  <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
  <link rel="shortcut icon" href="images/favicon.png">
  <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
  <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
  <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">
</head>

<body>
  <!-- =====  LODER  ===== -->
  <div class="loder"></div>
  <div class="wrapper">
    <div id="subscribe-me" class="modal animated fade in" role="dialog" data-keyboard="true" tabindex="-1">
      <div class="newsletter-popup">
        <img class="offer" src="assets/img/modal/newsbg.jpg" alt="offer">
        <div class="newsletter-popup-static newsletter-popup-top">
          <div class="popup-text">
            <div class="popup-title">50% <span>off</span></div>
            <div class="popup-desc">
              <div>Sign up and get 50% off your next Order</div>
            </div>
          </div>
          <form onsubmit="return  validatpopupemail();" method="post">
            <div class="form-group required">
              <input type="email" name="email-popup" id="email-popup" placeholder="Enter Your Email" class="form-control input-lg" required />
              <button type="submit" class="btn btn-default btn-lg" id="email-popup-submit">Subscribe</button>
              <label class="checkme">
                <input type="checkbox" value="" id="checkme" />Dont show again</label>
            </div>
          </form>
        </div>
      </div>
    </div>
    <!-- =====  HEADER START  ===== -->
    <header id="header">
      <div class="header-top">
        <div class="container">
          <div class="row">
            <div class="col-sm-6">
              <ul class="header-top-left">
                <li class="language dropdown"> <span class="dropdown-toggle" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" role="button"> <img src="images/English-icon.gif" alt="img"> English <span class="caret"></span> </span>
                  <ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                    <li><a href="#"><img src="images/English-icon.gif" alt="img"> English</a></li>
                    <li><a href="#"><img src="images/French-icon.gif" alt="img"> French</a></li>
                    <li><a href="#"><img src="images/German-icon.gif" alt="img"> German</a></li>
                  </ul>
                </li>
                <li class="currency dropdown"> <span class="dropdown-toggle" id="dropdownMenu12" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" role="button"> USD <span class="caret"></span> </span>
                  <ul class="dropdown-menu" aria-labelledby="dropdownMenu12">
                    <li><a href="#">USD</a></li>
                    <li><a href="#">EUR</a></li>
                    <li><a href="#">AUD</a></li>
                  </ul>
                </li>
              </ul>
            </div>
            <div class="col-sm-6">
              <ul class="header-top-right text-right">
                <li class="account"><a href="login.php">My Account</a></li>
                <li class="sitemap"><a href="#">Sitemap</a></li>
                <li class="cart"><a href="cart_page.php">My Cart</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="header">
        <div class="container">
          <nav class="navbar">
            <div class="navbar-header mtb_20"> <a class="navbar-brand" href="index.html"> <img alt="HealthCared" src="images/logo.png"> </a> </div>
            <div class="header-right pull-right mtb_50">
              <button class="navbar-toggle pull-left" type="button" data-toggle="collapse" data-target=".js-navbar-collapse"> <span class="i-bar"><i class="fa fa-bars"></i></span></button>
              <div class="shopping-icon">
                <div class="cart-item " data-target="#cart-dropdown" data-toggle="collapse" aria-expanded="true" role="button">Item's : <span class="cart-qty">02</span></div>
                <div id="cart-dropdown" class="cart-menu collapse">
                  <ul>
                    <li>
                      <table class="table table-striped">
                        <tbody>
                          <tr>
                            <td class="text-center"><a href="#"><img src="assets/img/cart/70x84.jpg" alt="iPod Classic" title="iPod Classic"></a></td>
                            <td class="text-left product-name"><a href="#">MacBook Pro</a>
                              <span class="text-left price">$20.00</span>
                              <input class="cart-qty" name="product_quantity" min="1" value="1" type="number">
                            </td>
                            <td class="text-center"><a class="close-cart"><i class="fa fa-times-circle"></i></a></td>
                          </tr>
                          <tr>
                            <td class="text-center"><a href="#"><img src="assets/img/cart/70x84.jpg" alt="iPod Classic" title="iPod Classic"></a></td>
                            <td class="text-left product-name"><a href="#">MacBook Pro</a>
                              <span class="text-left price">$20.00</span>
                              <input class="cart-qty" name="product_quantity" min="1" value="1" type="number">
                            </td>
                            <td class="text-center"><a class="close-cart"><i class="fa fa-times-circle"></i></a></td>
                          </tr>
                        </tbody>
                      </table>
                    </li>
                    <li>
                      <table class="table">
                        <tbody>
                          <tr>
                            <td class="text-right"><strong>Sub-Total</strong></td>
                            <td class="text-right">$2,100.00</td>
                          </tr>
                          <tr>
                            <td class="text-right"><strong>Eco Tax (-2.00)</strong></td>
                            <td class="text-right">$2.00</td>
                          </tr>
                          <tr>
                            <td class="text-right"><strong>VAT (20%)</strong></td>
                            <td class="text-right">$20.00</td>
                          </tr>
                          <tr>
                            <td class="text-right"><strong>Total</strong></td>
                            <td class="text-right">$2,122.00</td>
                          </tr>
                        </tbody>
                      </table>
                    </li>
                    <li>
                      <form action="cart_page.html">
                        <input class="btn pull-left mt_10" value="View cart" type="submit">
                      </form>
                      <form action="checkout_page.html">
                        <input class="btn pull-right mt_10" value="Checkout" type="submit">
                      </form>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="main-search pull-right">
                <div class="search-overlay">
                  <!-- Close Icon -->
                  <a href="javascript:void(0)" class="search-overlay-close"></a>
                  <!-- End Close Icon -->
                  <div class="container">
                    <!-- Search Form -->
                    <form role="search" id="searchform" action="/search" method="get">
                      <label class="h5 normal search-input-label">Enter keywords To Search Entire Store</label>
                      <input value="" name="q" placeholder="Search here..." type="search">
                      <button type="submit"></button>
                    </form>
                    <!-- End Search Form -->
                  </div>
                </div>
                <div class="header-search"> <a id="search-overlay-btn"></a> </div>
              </div>
            </div>
            <div class="collapse navbar-collapse js-navbar-collapse pull-right">
              <ul id="menu" class="nav navbar-nav">
                <li> <a href="index.html">Home</a></li>
                <li> <a href="category_page.html">Shop</a></li>
                <li> <a href="blog_page.html">Blog</a></li>
                <li class="dropdown mega-dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">Collection </a>
                  <ul class="dropdown-menu mega-dropdown-menu row">
                    <li class="col-md-3">
                      <ul>
                        <li class="dropdown-header">Women's</li>
                        <li><a href="#">Unique Features</a></li>
                        <li><a href="#">Image Responsive</a></li>
                        <li><a href="#">Auto Carousel</a></li>
                        <li><a href="#">Newsletter Form</a></li>
                        <li><a href="#">Four columns</a></li>
                        <li><a href="#">Four columns</a></li>
                        <li><a href="#">Good Typography</a></li>
                      </ul>
                    </li>
                    <li class="col-md-3">
                      <ul>
                        <li class="dropdown-header">Man's</li>
                        <li><a href="#">Unique Features</a></li>
                        <li><a href="#">Image Responsive</a></li>
                        <li><a href="#">Four columns</a></li>
                        <li><a href="#">Auto Carousel</a></li>
                        <li><a href="#">Newsletter Form</a></li>
                        <li><a href="#">Four columns</a></li>
                        <li><a href="#">Good Typography</a></li>
                      </ul>
                    </li>
                    <li class="col-md-3">
                      <ul>
                        <li class="dropdown-header">Children's</li>
                        <li><a href="#">Unique Features</a></li>
                        <li><a href="#">Four columns</a></li>
                        <li><a href="#">Image Responsive</a></li>
                        <li><a href="#">Auto Carousel</a></li>
                        <li><a href="#">Newsletter Form</a></li>
                        <li><a href="#">Four columns</a></li>
                        <li><a href="#">Good Typography</a></li>
                      </ul>
                    </li>
                    <li class="col-md-3">
                      <ul>
                        <li id="myCarousel" class="carousel slide" data-ride="carousel">
                          <div class="carousel-inner">
                            <div class="item active"> <a href="#"><img src="images/menu-banner1.jpg" class="img-responsive" alt="Banner1"></a></div>
                            <!-- End Item -->
                            <div class="item"> <a href="#"><img src="images/menu-banner2.jpg" class="img-responsive" alt="Banner1"></a></div>
                            <!-- End Item -->
                            <div class="item"> <a href="#"><img src="images/menu-banner3.jpg" class="img-responsive" alt="Banner1"></a></div>
                            <!-- End Item -->
                          </div>
                          <!-- End Carousel Inner -->
                        </li>
                        <!-- /.carousel -->
                      </ul>
                    </li>
                  </ul>
                </li>
                <li class="dropdown"> <a href="#" class="dropdown-toggle" data-toggle="dropdown">Pages </a>
                  <ul class="dropdown-menu">
                    <li> <a href="contact_us.html">Contact us</a></li>
                    <li> <a href="cart_page.html">Cart</a></li>
                    <li> <a href="checkout_page.html">Checkout</a></li>
                    <li> <a href="product_detail_page.html">Product Detail Page</a></li>
                    <li> <a href="single_blog.html">Single Post</a></li>
                  </ul>
                </li>
                <li> <a href="about.html">About us</a></li>
              </ul>
            </div>
            <!-- /.nav-collapse -->
          </nav>
        </div>
      </div>
      <div class="header-bottom">
        <div class="container">
          <div class="row">
            <div class="col-sm-4 col-md-4 col-lg-3">
              <div class="category">
                <div class="menu-bar" data-target="#category-menu,#category-menu-responsive" data-toggle="collapse" aria-expanded="true" role="button">
                  <h4 class="category_text">Top category</h4>
                  <span class="i-bar"><i class="fa fa-bars"></i></span></div>
              </div>
              <div id="category-menu-responsive" class="navbar collapse " aria-expanded="true" style="" role="button">
                <div class="nav-responsive">
                  <ul class="nav  main-navigation collapse in">
                    <li><a href="#">Electronic Accessories</a></li>
                    <li><a href="#">TV & Home Appliances</a></li>
                    <li><a href="#">Health & Beauty</a></li>
                    <li><a href="#">Babies & Toys</a></li>
                    <li><a href="#">Groceries & Pets</a></li>
                    <li><a href="#">Home & Lifestyle</a></li>
                    <li><a href="#">Women's Fashion</a></li>
                    <li><a href="#">Men's Fashion</a></li>
                    <li><a href="#">Nursery & Plant</a></li>
                    <li><a href="#">Watches & Accessories</a></li>
                    <li><a href="#">Sports & Outdoor</a></li>
                    <li><a href="#">Nursery Accessories</a></li>
                    <li><a href="#">Automotive & Motorbike</a></li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-sm-8 col-md-8 col-lg-9">
              <div class="header-bottom-right offers">
              	<div class="marquee"><span><i class="fa fa-circle" aria-hidden="true"></i>It's Sexual Health Week!</span>
                  <span><i class="fa fa-circle" aria-hidden="true"></i>Our 5 Tips for a Healthy Summer</span>
                  <span><i class="fa fa-circle" aria-hidden="true"></i>Sugar health at risk?</span>
                  <span><i class="fa fa-circle" aria-hidden="true"></i>The Olay Ranges - What do they do?</span>
                  <span><i class="fa fa-circle" aria-hidden="true"></i>Body fat - what is it and why do we need it?</span>
                  <span><i class="fa fa-circle" aria-hidden="true"></i>Can a pillow help you to lose weight?</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>
    <!-- =====  HEADER END  ===== -->
    <!-- =====  CONTAINER START  ===== -->
    <div class="container">
      <div class="row ">
        <div id="column-left" class="col-sm-4 col-md-4 col-lg-3 ">
          <div id="category-menu" class="navbar collapse mb_40 hidden-sm-down in" aria-expanded="true" style="" role="button">
            <?php
              if (isset($_SESSION['msg'])) { echo $_SESSION['msg'];
                session_unset();
              } 

              $data = [];
              $data['table'] = "categories";
              $data['columns'] = ['id','category','created_at'];
              $data['where'] = "";
              $data['order_by'] = "id desc";

              $ProductController = ProductController::getProductController();
              $data = $ProductController->view($data);
                                    
              foreach ($data as $key => $value) {
                $name_to_array = explode(" ",$value->category);
                $name = implode("-",$name_to_array);
            ?>
            <div class="nav-responsive">
              <ul class="nav  main-navigation collapse in ">
                <li><a href="category_page.php?item<?php echo $name ?>&id=<?php echo "$value->id" ?>"><?php echo "$value->category"; ?></a></li>
              </ul>
            </div>
          <?php } ?>
          </div>
          <div class="left_banner left-sidebar-widget mt_30 mb_50"> <a href="#"><img src="assets/img/left_banar/left1.jpg" alt="Left Banner" class="img-responsive" /></a> </div>
          <div class="left-cms left-sidebar-widget mb_50">
            <ul>
              <li>
                <div class="feature-i-left ptb_40">
                  <div class="icon-right Shipping"></div>
                  <h6>Free Shipping</h6>
                  <p>Free delivery worldwide</p>
                </div>
              </li>
              <li>
                <div class="feature-i-left ptb_40">
                  <div class="icon-right Order"></div>
                  <h6>Order Online</h6>
                  <p>Hours : 8am - 11pm</p>
                </div>
              </li>
              <li>
                <div class="feature-i-left ptb_40">
                  <div class="icon-right Save"></div>
                  <h6>Shop And Save</h6>
                  <p>For All Spices & Herbs</p>
                </div>
              </li>
              <li>
                <div class="feature-i-left ptb_40">
                  <div class="icon-right Safe"></div>
                  <h6>Safe Shoping</h6>
                  <p>Ensure genuine 100%</p>
                </div>
              </li>
            </ul>
          </div>
          <div class="left-special left-sidebar-widget mb_50">
            <div class="heading-part mb_20 ">
              <h2 class="main_title">Top Products</h2>
            </div>
            <div id="left-special" class="owl-carousel">
              <ul class="row ">
                <?php
                    if (isset($_SESSION['msg'])) { echo $_SESSION['msg'];
                      session_unset();
                    } 

                      
                    //$id = $_GET['category_id'];
                    $data = [];
                    $data['table'] = "products";
                    $data['columns'] = ['id','name','sku', 'buying_price','description', 'selling_price','discount','vat','size', 'color', 'stock_qty','category_id', 'sub_category_id', 'brand_id', 'supplier_id', 'created_at' ];
                    $data['where'] = "category_id=16";
                    $data['order_by'] = "id desc";
                    
                    $ProductController = ProductController::getProductController();
                    $data = $ProductController->view($data);

                    foreach ($data as $key => $value) {
                      $name_to_array = explode(" ",$value->name);
                      $name = implode("-",$name_to_array);
                  ?>
                <li class="item product-layout-left mb_20">
                  <div class="product-list col-xs-4">
                    <div class="product-thumb">
                      <div class="image product-imageblock"> 
                        <a href="product_detail_page.php?item=<?php echo $name; ?>&id=<?php echo $value->id?>"> 
                          <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="../../assetes/default_image/<?php echo ProductImage::getProductIdToProductImage($value->id)[1]->image_name ?>"> 
                          <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="../../assetes/sub_image/<?php echo ProductImage::getProductIdToProductImage($value->id)[0]->image_name ?>"> 
                        </a> 
                      </div>
                    </div>
                  </div>
                  <div class="col-xs-8">
                    <div class="caption product-detail">
                      <h6 class="product-name"><a href="product_detail_page.php?item<?php echo $name ?>&id=<?php echo "$value->id" ?>"><?php echo "$value->name"; ?></a></h6>
                      <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                      <span class="price"><span class="amount">
                        <span class="currencySymbol">৳</span><?php echo "$value->selling_price"; ?>
                      </span>
                      </span>
                    </div>
                  </div>
                </li>
              <?php } ?>
                <!--
                <li class="item product-layout-left mb_20">
                  <div class="product-list col-xs-4">
                    <div class="product-thumb">
                      <div class="image product-imageblock"> 
                        <a href="product_detail_page.html"> 
                          <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/left_product/defult/product4.jpg"> 
                          <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/left_product/sub/product4-1.jpg"> 
                        </a> 
                      </div>
                    </div>
                  </div>
                  <div class="col-xs-8">
                    <div class="caption product-detail">
                      <h6 class="product-name"><a href="#">Latin literature from 45 BC, making it over old.</a></h6>
                      <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                      <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                      </span>
                    </div>
                  </div>
                </li>
                <li class="item product-layout-left mb_20">
                  <div class="product-list col-xs-4">
                    <div class="product-thumb">
                      <div class="image product-imageblock"> 
                        <a href="product_detail_page.html"> 
                          <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/left_product/defult/product4.jpg"> 
                          <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/left_product/sub/product4-1.jpg"> 
                        </a> 
                      </div>
                    </div>
                  </div>
                  <div class="col-xs-8">
                    <div class="caption product-detail">
                      <h6 class="product-name"><a href="#">Latin literature from 45 BC, making it over old.</a></h6>
                      <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                      <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                      </span>
                    </div>
                  </div>
                </li>-->
              </ul>
              <!--
              <ul class="row ">
                <li class="item product-layout-left mb_20">
                  <div class="product-list col-xs-4">
                    <div class="product-thumb">
                      <div class="image product-imageblock"> <a href="product_detail_page.html"> <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="images/product/product3.jpg"> <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="images/product/product3-1.jpg"> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-8">
                    <div class="caption product-detail">
                      <h6 class="product-name"><a href="#">Latin literature from 45 BC, making it over old.</a></h6>
                      <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                      <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                      </span>
                    </div>
                  </div>
                </li>
                <li class="item product-layout-left mb_20">
                  <div class="product-list col-xs-4">
                    <div class="product-thumb">
                      <div class="image product-imageblock"> <a href="product_detail_page.html"> <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="images/product/product5.jpg"> <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="images/product/product5-1.jpg"> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-8">
                    <div class="caption product-detail">
                      <h6 class="product-name"><a href="#">Latin literature from 45 BC, making it over old.</a></h6>
                      <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                      <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                      </span>
                    </div>
                  </div>
                </li>
                <li class="item product-layout-left mb_20">
                  <div class="product-list col-xs-4">
                    <div class="product-thumb">
                      <div class="image product-imageblock"> <a href="product_detail_page.html"> <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="images/product/product6.jpg"> <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="images/product/product6-1.jpg"> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-8">
                    <div class="caption product-detail">
                      <h6 class="product-name"><a href="#">Latin literature from 45 BC, making it over old.</a></h6>
                      <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                      <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                      </span>
                    </div>
                  </div>
                </li>
              </ul>
              <ul class="row ">
                <li class="item product-layout-left mb_20">
                  <div class="product-list col-xs-4">
                    <div class="product-thumb">
                      <div class="image product-imageblock"> <a href="product_detail_page.html"> <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="images/product/product7.jpg"> <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="images/product/product7-1.jpg"> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-8">
                    <div class="caption product-detail">
                      <h6 class="product-name"><a href="#">Latin literature from 45 BC, making it over old.</a></h6>
                      <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                      <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                      </span>
                    </div>
                  </div>
                </li>
                <li class="item product-layout-left mb_20">
                  <div class="product-list col-xs-4">
                    <div class="product-thumb">
                      <div class="image product-imageblock"> <a href="product_detail_page.html"> <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="images/product/product8.jpg"> <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="images/product/product8-1.jpg"> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-8">
                    <div class="caption product-detail">
                      <h6 class="product-name"><a href="#">Latin literature from 45 BC, making it over old.</a></h6>
                      <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                      <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                      </span>
                    </div>
                  </div>
                </li>
                <li class="item product-layout-left mb_20">
                  <div class="product-list col-xs-4">
                    <div class="product-thumb">
                      <div class="image product-imageblock"> <a href="product_detail_page.html"> <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="images/product/product9.jpg"> <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="images/product/product9-1.jpg"> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-8">
                    <div class="caption product-detail">
                      <h6 class="product-name"><a href="#">Latin literature from 45 BC, making it over old.</a></h6>
                      <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                      <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                      </span>
                    </div>
                  </div>
                </li>
              </ul>
              <ul class="row ">
                <li class="item product-layout-left mb_20">
                  <div class="product-list col-xs-4">
                    <div class="product-thumb">
                      <div class="image product-imageblock"> <a href="product_detail_page.html"> <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="images/product/product10.jpg"> <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="images/product/product10-1.jpg"> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-8">
                    <div class="caption product-detail">
                      <h6 class="product-name"><a href="#">Latin literature from 45 BC, making it over old.</a></h6>
                      <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                      <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                      </span>
                    </div>
                  </div>
                </li>
                <li class="item product-layout-left mb_20">
                  <div class="product-list col-xs-4">
                    <div class="product-thumb">
                      <div class="image product-imageblock"> <a href="product_detail_page.html"> <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="images/product/product1.jpg"> <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="images/product/product1-1.jpg"> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-8">
                    <div class="caption product-detail">
                      <h6 class="product-name"><a href="#">Latin literature from 45 BC, making it over old.</a></h6>
                      <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                      <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                      </span>
                    </div>
                  </div>
                </li>
                <li class="item product-layout-left mb_20">
                  <div class="product-list col-xs-4">
                    <div class="product-thumb">
                      <div class="image product-imageblock"> <a href="product_detail_page.html"> <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="images/product/product2.jpg"> <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="images/product/product2-1.jpg"> </a> </div>
                    </div>
                  </div>
                  <div class="col-xs-8">
                    <div class="caption product-detail">
                      <h6 class="product-name"><a href="#">Latin literature from 45 BC, making it over old.</a></h6>
                      <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                      <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                      </span>
                    </div>
                  </div>
                </li>
              </ul>
            -->
            </div>
          </div>
          <div class="left_banner left-sidebar-widget mb_50"> <a href="#"><img src="assets/img/left_banar/left1.jpg" alt="Left Banner" class="img-responsive" /></a> </div>
          <div class="Testimonial left-sidebar-widget mb_50">
            <div class="heading-part mb_20 ">
              <h2 class="main_title">Testimonial</h2>
            </div>
            <div class="client owl-carousel text-center pt_10">
              <div class="item client-detail">
                <div class="client-avatar"> <img alt="" src="images/user1.jpg"> </div>
                <div class="client-title  mt_30"><strong>joseph Lui</strong></div>
                <div class="client-designation mb_10">php Developer</div>
                <p><i class="fa fa-quote-left" aria-hidden="true"></i>Lorem ipsum dolor sit amet, volumus oporteat his at sea in Rem ipsum dolor sit amet, sea in odio ..</p>
              </div>
              <div class="item client-detail">
                <div class="client-avatar"> <img alt="" src="images/user2.jpg"> </div>
                <div class="client-title  mt_30"><strong>joseph Lui</strong></div>
                <div class="client-designation mb_10">php Developer</div>
                <p><i class="fa fa-quote-left" aria-hidden="true"></i>Lorem ipsum dolor sit amet, volumus oporteat his at sea in Rem ipsum dolor sit amet, sea in odio ..</p>
              </div>
              <div class="item client-detail">
                <div class="client-avatar"> <img alt="" src="images/user3.jpg"> </div>
                <div class="client-title  mt_30"><strong>joseph Lui</strong></div>
                <div class="client-designation mb_10">php Developer</div>
                <p><i class="fa fa-quote-left" aria-hidden="true"></i>Lorem ipsum dolor sit amet, volumus oporteat his at sea in Rem ipsum dolor sit amet, sea in odio ..</p>
              </div>
            </div>
          </div>
          <div class="Tags left-sidebar-widget mb_50">
            <div class="heading-part mb_20 ">
              <h2 class="main_title">Tags</h2>
            </div>
            <ul>
                <li><a href="#">Electronic Accessories</a></li>
                <li><a href="#">TV & Home Appliances</a></li>
                <li><a href="#">Health & Beauty</a></li>
                <li><a href="#">Babies & Toys</a></li>
                <li><a href="#">Groceries & Pets</a></li>
                <li><a href="#">Home & Lifestyle</a></li>
                <li><a href="#">Women's Fashion</a></li>
                <li><a href="#">Men's Fashion</a></li>
                <li><a href="#">Nursery & Plant</a></li>
                <li><a href="#">Watches & Accessories</a></li>
                <li><a href="#">Sports & Outdoor</a></li>
                <li><a href="#">Nursery Accessories</a></li>
                <li><a href="#">Automotive & Motorbike</a></li>
          </div>
        </div>
        <div id="column-right" class="col-sm-8 col-md-8 col-lg-9 mtb_30">
          <!-- =====  BANNER STRAT  ===== -->
          <div class="banner">
            <div class="main-banner owl-carousel">
              <div class="item"><a href="#"><img src="assets/img/slider/main_banner1.jpg" alt="Main Banner" class="img-responsive" /></a></div>
              <div class="item"><a href="#"><img src="assets/img/slider/main_banner2.jpg" alt="Main Banner" class="img-responsive" /></a></div>
            </div>
          </div>
          <!-- =====  BANNER END  ===== -->
          <!-- =====  SUB BANNER  STRAT ===== -->
          <div class="row">
            <div class="cms_banner mt_10">
              <div class="col-xs-6 col-sm-12 col-md-6 mt_20">
                <div id="subbanner1" class="sub-hover"> 
                  <a href="#">
                    <img src="assets/img/cms/sub1.jpg" alt="Sub Banner1" class="img-responsive">
                  </a>
                  <div class="bannertext">
                    <h2>Full HD Camera</h2>
                    <p class="mt_10">Different Resolutions</p>
                  </div>
                </div>
              </div>
              <div class="col-xs-6 col-sm-12 col-md-6 mt_20">
                <div id="subbanner2" class="sub-hover"> 
                  <a href="#">
                    <img src="assets/img/cms/sub1.jpg" alt="Sub Banner1" class="img-responsive">
                  </a>
                  <div class="bannertext">
                    <h2>smart watches</h2>
                    <p class="mt_10">Most Popular Brands</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- =====  SUB BANNER END  ===== -->
          <!-- =====  PRODUCT TAB  ===== -->
          <div id="product-tab" class="mt_40">
            <div class="heading-part mb_20 ">
              <h2 class="main_title">Home Electronics</h2>
            </div>
            <ul class="nav text-right">
              <li class="active"> <a href="#nArrivals" data-toggle="tab">New Arrivals</a> </li>
              <li><a href="#Bestsellers" data-toggle="tab">Bestsellers</a> </li>
              <li><a href="#Featured" data-toggle="tab">Featured</a> </li>
            </ul>
            <div class="tab-content clearfix box">
              <div class="tab-pane active" id="nArrivals">
                <div class="nArrivals owl-carousel">
                  <?php
                    if (isset($_SESSION['msg'])) { echo $_SESSION['msg'];
                      session_unset();
                    } 

                    $data = [];
                    $data['table'] = "products";
                    $data['columns'] = ['id','name','sku', 'buying_price', 'selling_price','discount','vat','size', 'color', 'stock_qty','category_id', 'sub_category_id', 'brand_id', 'supplier_id', 'created_at' ];
                    $data['where'] = "";
                    $data['order_by'] = "id desc";


                    $ProductController = ProductController::getProductController();
                    $data = $ProductController->view($data);
                     
                    foreach ($data as $key => $value) {
                      $name_to_array = explode(" ",$value->name);
                      $name = implode("-",$name_to_array);
                  ?>
                  <div class="product-grid">
                    <div class="item">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.php?item=<?php echo $name; ?>&id=<?php echo $value->id?>"> 
                            <img data-name="product_image" src="../../assetes/default_image/<?php echo ProductImage::getProductIdToProductImage($value->id)[1]->image_name ?>" alt="iPod Classic" title="iPod Classic" class="img-responsive"> 
                            <img data-name="product_image" src="../../assetes/sub_image/<?php echo ProductImage::getProductIdToProductImage($value->id)[0]->image_name ?>" alt="iPod Classic" title="iPod Classic" class="img-responsive"> 
                          </a> 
                        </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20">
                            <a href="product_detail_page.php?item<?php echo $name ?>&id=<?php echo "$value->id" ?>"title="Casual Shirt With Ruffle Hem"><?php echo "$value->name"; ?>
                            </a>
                          </h6>
                          <div class="rating"> 
                            <span class="fa fa-stack">
                              <i class="fa fa-star-o fa-stack-1x"></i>
                              <i class="fa fa-star fa-stack-1x"></i>
                            </span> 
                            <span class="fa fa-stack">
                              <i class="fa fa-star-o fa-stack-1x"></i>
                              <i class="fa fa-star fa-stack-1x"></i>
                            </span> 
                            <span class="fa fa-stack">
                              <i class="fa fa-star-o fa-stack-1x"></i>
                              <i class="fa fa-star fa-stack-1x"></i>
                            </span> 
                            <span class="fa fa-stack">
                              <i class="fa fa-star-o fa-stack-1x"></i>
                              <i class="fa fa-star fa-stack-1x"></i>
                            </span> 
                            <span class="fa fa-stack">
                              <i class="fa fa-star-o fa-stack-1x"></i>
                              <i class="fa fa-star fa-stack-x"></i>
                            </span> 
                          </div>
                          <span class="price">
                            <span class="amount">
                              <span class="currencySymbol">৳</span><?php echo "$value->selling_price"; ?>
                            </span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist">
                              <a href="#">
                                <span>wishlist</span>
                              </a>
                            </div>
                            <div class="quickview">
                              <a href="#">
                                <span>Quick View</span>
                              </a>
                            </div>
                            <div class="compare">
                              <a href="#">
                                <span>Compare</span>
                              </a>
                            </div>
                            <div class="add-to-cart">
                              <a href="#">
                                <span>Add to cart</span>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!--
                    <div class="item">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img data-name="product_image" src="assets/img/products/defult_img/product2.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> 
                            <img data-name="product_image" src="assets/img/products/sub_img/product2-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive">
                          </a> 
                        </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20">
                            <a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.
                            </a>
                          </h6>
                          <div class="rating"> 
                            <span class="fa fa-stack">
                              <i class="fa fa-star-o fa-stack-1x"></i>
                              <i class="fa fa-star fa-stack-1x"></i>
                            </span> 
                            <span class="fa fa-stack">
                              <i class="fa fa-star-o fa-stack-1x"></i>
                              <i class="fa fa-star fa-stack-1x"></i>
                            </span> 
                            <span class="fa fa-stack">
                              <i class="fa fa-star-o fa-stack-1x"></i>
                              <i class="fa fa-star fa-stack-1x"></i>
                            </span> 
                            <span class="fa fa-stack">
                              <i class="fa fa-star-o fa-stack-1x"></i>
                              <i class="fa fa-star fa-stack-1x"></i>
                            </span> 
                            <span class="fa fa-stack">
                              <i class="fa fa-star-o fa-stack-1x"></i>
                              <i class="fa fa-star fa-stack-x"></i>
                            </span> 
                          </div>
                          <span class="price">
                            <span class="amount">
                              <span class="currencySymbol">$</span>70.00
                            </span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist">
                              <a href="#">
                                <span>wishlist</span>
                              </a>
                            </div>
                            <div class="quickview">
                              <a href="#">
                                <span>Quick View</span>
                              </a>
                            </div>
                            <div class="compare">
                              <a href="#">
                                <span>Compare</span>
                              </a>
                            </div>
                            <div class="add-to-cart">
                              <a href="#">
                                <span>Add to cart</span>
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>-->
                  </div>
                <?php } ?>
                </div>
              </div>
              <!--
              <div class="tab-pane" id="Bestsellers">
                <div class="Bestsellers owl-carousel">
                  <div class="product-grid">
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product1-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product2.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product2-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="product-grid">
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product3.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product3-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product4.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product4-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="product-grid">
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product5.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product5-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product6.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product6-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="product-grid">
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product7.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product7-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product8.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product8-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="product-grid">
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product9.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product9-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product10.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product10-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="tab-pane" id="Featured">
                <div class="Featured owl-carousel">
                  <div class="product-grid">
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product1-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product2.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product2-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="product-grid">
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product3.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product3-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product4.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product4-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="product-grid">
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product5.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product5-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product7.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product7-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="product-grid">
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product8.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product8-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product9.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product9-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="product-grid">
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product10.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product10-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="item">
                      <div class="product-thumb  mb_30">
                        <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product1-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                        <div class="caption product-detail text-left">
                          <h6 data-name="product_name" class="product-name mt_20"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                          <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                          <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                          </span>
                          <div class="button-group text-center">
                            <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                            <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                            <div class="compare"><a href="#"><span>Compare</span></a></div>
                            <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>-->
            </div>
          </div>
          <!-- =====  PRODUCT TAB  END ===== -->
          <!-- =====  SUB BANNER  STRAT ===== -->
          <div class="row">
            <div class="cms_banner mt_40 mb_50">
              <div class="col-xs-12">
                <div id="subbanner3" class="banner sub-hover"> <a href="#"><img src="assets/img/rigth_banner/sub3.gif" alt="Sub Banner3" class="img-responsive"></a> </div>
              </div>
            </div>
          </div>
          <!-- =====  SUB BANNER END  ===== -->
          <!-- =====  sale product  ===== 
          <div id="sale-product">
            <div class="heading-part mb_20 ">
              <h2 class="main_title">Home Electronics</h2>
            </div>
            <div class="Specials owl-carousel">
              <div class="item product-layout product-list">
                <div class="product-thumb">
                  <div class="image product-imageblock"> 
                    <a href="product_detail_page.html"> 
                      <img data-name="product_image" src="assets/img/products/defult_img/product8.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> 
                      <img src="assets/img/products/sub_img/product8-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> 
                    </a> 
                  </div>
                  <div class="caption product-detail text-left">
                    <h6 data-name="product_name" class="product-name">
                      <a href="#" title="Casual Shirt With Ruffle Hem">
                        Latin literature from 45 BC, making it over old.
                      </a>
                    </h6>
                    <div class="rating"> 
                      <span class="fa fa-stack">
                        <i class="fa fa-star-o fa-stack-1x"></i>
                        <i class="fa fa-star fa-stack-1x"></i>
                      </span> 
                      <span class="fa fa-stack">
                        <i class="fa fa-star-o fa-stack-1x"></i>
                        <i class="fa fa-star fa-stack-1x"></i></span> 
                        <span class="fa fa-stack">
                          <i class="fa fa-star-o fa-stack-1x"></i>
                          <i class="fa fa-star fa-stack-1x"></i>
                        </span> 
                        <span class="fa fa-stack">
                          <i class="fa fa-star-o fa-stack-1x"></i>
                          <i class="fa fa-star fa-stack-1x"></i>
                        </span> 
                        <span class="fa fa-stack">
                          <i class="fa fa-star-o fa-stack-1x"></i>
                          <i class="fa fa-star fa-stack-x"></i>
                        </span> 
                      </div>
                    <span class="price">
                      <span class="amount">
                        <span class="currencySymbol">$</span>70.00
                      </span>
                    </span>
                    <p class="product-desc mt_20"> More room to move. With 80GB or 160GB of storage and up to 40 hours of battery life, the new iPod classic lets you enjoy up to 40,000 songs or up to 200 hours of video or any combination wherever you go.Cover Flow. Browse through your music collection by flipping..</p>
                    <div class="timer mt_80">
                      <div class="days"></div>
                      <div class="hours"></div>
                      <div class="minutes"></div>
                      <div class="seconds"></div>
                    </div>
                    <div class="button-group text-center">
                      <div class="wishlist">
                        <a href="#">
                          <span>wishlist</span>
                        </a>
                      </div>
                      <div class="quickview">
                        <a href="#">
                          <span>Quick View</span>
                        </a>
                      </div>
                      <div class="compare">
                        <a href="#">
                          <span>Compare</span>
                        </a>
                      </div>
                      <div class="add-to-cart">
                        <a href="#">
                          <span>Add to cart</span>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item product-layout product-list">
                <div class="product-thumb">
                  <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product7.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product7-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                  <div class="caption product-detail text-left">
                    <h6 data-name="product_name" class="product-name"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                    <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                    <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                    </span>
                    <p class="product-desc mt_20"> More room to move. With 80GB or 160GB of storage and up to 40 hours of battery life, the new iPod classic lets you enjoy up to 40,000 songs or up to 200 hours of video or any combination wherever you go.Cover Flow. Browse through your music collection by flipping..</p>
                    <div class="timer mt_80">
                      <div class="days"></div>
                      <div class="hours"></div>
                      <div class="minutes"></div>
                      <div class="seconds"></div>
                    </div>
                    <div class="button-group text-center">
                      <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                      <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                      <div class="compare"><a href="#"><span>Compare</span></a></div>
                      <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="item product-layout product-list">
                <div class="product-thumb">
                  <div class="image product-imageblock"> <a href="product_detail_page.html"> <img data-name="product_image" src="images/product/product6.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> <img src="images/product/product6-1.jpg" alt="iPod Classic" title="iPod Classic" class="img-responsive"> </a> </div>
                  <div class="caption product-detail text-left">
                    <h6 data-name="product_name" class="product-name"><a href="#" title="Casual Shirt With Ruffle Hem">Latin literature from 45 BC, making it over old.</a></h6>
                    <div class="rating"> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-1x"></i></span> <span class="fa fa-stack"><i class="fa fa-star-o fa-stack-1x"></i><i class="fa fa-star fa-stack-x"></i></span> </div>
                    <span class="price"><span class="amount"><span class="currencySymbol">$</span>70.00</span>
                    </span>
                    <p class="product-desc mt_20"> More room to move. With 80GB or 160GB of storage and up to 40 hours of battery life, the new iPod classic lets you enjoy up to 40,000 songs or up to 200 hours of video or any combination wherever you go.Cover Flow. Browse through your music collection by flipping..</p>
                    <div class="timer mt_80">
                      <div class="days"></div>
                      <div class="hours"></div>
                      <div class="minutes"></div>
                      <div class="seconds"></div>
                    </div>
                    <div class="button-group text-center">
                      <div class="wishlist"><a href="#"><span>wishlist</span></a></div>
                      <div class="quickview"><a href="#"><span>Quick View</span></a></div>
                      <div class="compare"><a href="#"><span>Compare</span></a></div>
                      <div class="add-to-cart"><a href="#"><span>Add to cart</span></a></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>-->
          <!-- =====  sale product end ===== -->
          <!-- =====  SUB BANNER  STRAT ===== -->
          <div class="row">
            <div class="cms_banner mt_60 mb_50">
              <div class="col-xs-12">
                <div id="subbanner4" class="banner sub-hover"> <a href="#"><img src="assets/img/rigth_banner/sub4.jpg" alt="Sub Banner4" class="img-responsive"></a>
                  <div class="bannertext"> </div>
                </div>
              </div>
            </div>
          </div>
          <!-- =====  SUB BANNER END  ===== -->
          <!-- =====  product ===== -->
          <div class="row">
            <?php
                    if (isset($_SESSION['msg'])) { echo $_SESSION['msg'];
                      session_unset();
                    } 

                    $data = [];
                    $data['table'] = "products";
                    $data['columns'] = ['id','name','sku', 'buying_price', 'selling_price','discount','vat','size', 'color', 'stock_qty','category_id', 'sub_category_id', 'brand_id', 'supplier_id', 'created_at' ];
                    $data['where'] = "category_id=15";
                    $data['order_by'] = "id desc";

                    $ProductController = ProductController::getProductController();
                    $data = $ProductController->view($data);
                                    
                    foreach ($data as $key => $value) {
                      $name_to_array = explode(" ",$value->name);
                      $name = implode("-",$name_to_array);
                  ?>
            <div class="col-md-4">
              <div class="heading-part mb_20 ">
                <h2 class="main_title">Featured</h2>
              </div>
              <div id="featu-pro" class="owl-carousel">
                <ul class="row ">
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.php?item=<?php echo $name; ?>&id=<?php echo $value->id?>"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="../../assetes/default_image/<?php echo ProductImage::getProductIdToProductImage($value->id)[1]->image_name ?>"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="../../assetes/sub_image/<?php echo ProductImage::getProductIdToProductImage($value->id)[0]->image_name ?>"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="product_detail_page.php?item=<?php echo $name; ?>&id=<?php echo $value->id?>"><?php echo "$value->name"; ?></a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                              <span class="currencySymbol">৳</span><?php echo "$value->selling_price"; ?>
                            </span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.php?item=<?php echo $name; ?>&id=<?php echo $value->id?>"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="../../assetes/default_image/<?php echo ProductImage::getProductIdToProductImage($value->id)[1]->image_name ?>"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="../../assetes/sub_image/<?php echo ProductImage::getProductIdToProductImage($value->id)[0]->image_name ?>"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="product_detail_page.php?item=<?php echo $name; ?>&id=<?php echo $value->id?>"><?php echo "$value->name"; ?></a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                              <span class="currencySymbol">৳</span><?php echo "$value->selling_price"; ?>
                            </span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.php?item=<?php echo $name; ?>&id=<?php echo $value->id?>"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="../../assetes/default_image/<?php echo ProductImage::getProductIdToProductImage($value->id)[1]->image_name ?>"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="../../assetes/sub_image/<?php echo ProductImage::getProductIdToProductImage($value->id)[0]->image_name ?>"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="product_detail_page.php?item=<?php echo $name; ?>&id=<?php echo $value->id?>"><?php echo "$value->name"; ?></a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                              <span class="currencySymbol">৳</span><?php echo "$value->selling_price"; ?>
                            </span>
                        </span>
                      </div>
                    </div>
                  </li>
                </ul><!--
                <ul class="row ">
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                </ul>
                <ul class="row ">
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                </ul>
                <ul class="row ">
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                </ul>-->
              </div>
            </div>
            <!--<div class="col-md-4">
              <div class="heading-part mb_20 ">
                <h2 class="main_title">Featured</h2>
              </div>
              <div id="featu-pro" class="owl-carousel">
                <ul class="row ">
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                </ul>
                <ul class="row ">
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                </ul>
                <ul class="row ">
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                </ul>
                <ul class="row ">
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
            <div class="col-md-4">
              <div class="heading-part mb_20 ">
                <h2 class="main_title">Featured</h2>
              </div>
              <div id="featu-pro" class="owl-carousel">
                <ul class="row ">
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                </ul>
                <ul class="row ">
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                </ul>
                <ul class="row ">
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                </ul>
                <ul class="row ">
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                  <li class="item product-layout-left mb_20">
                    <div class="product-list col-xs-4">
                      <div class="product-thumb">
                        <div class="image product-imageblock"> 
                          <a href="product_detail_page.html"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/defult_img/product5.jpg"> 
                            <img class="img-responsive" title="iPod Classic" alt="iPod Classic" src="assets/img/products/sub_img/product5-1.jpg"> 
                          </a> 
                        </div>
                      </div>
                    </div>
                    <div class="col-xs-8">
                      <div class="caption product-detail">
                        <h6 class="product-name">
                          <a href="#">Latin literature from 45 BC, making it over old.</a>
                        </h6>
                        <div class="rating"> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-1x"></i>
                          </span> 
                          <span class="fa fa-stack">
                            <i class="fa fa-star-o fa-stack-1x"></i>
                            <i class="fa fa-star fa-stack-x"></i>
                          </span> 
                        </div>
                        <span class="price">
                          <span class="amount">
                            <span class="currencySymbol">$</span>70.00</span>
                        </span>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
            </div>-->
          <?php } ?>
          </div>

          <!-- =====  product end  ===== -->
          <!-- =====  Blog ===== -->
          <div id="Blog" class="mt_40">
            <div class="heading-part mb_20 ">
              <h2 class="main_title">Latest from the Blog</h2>
            </div>
            <div class="blog-contain box">
              <div class="blog owl-carousel ">
                <div class="item">
                  <div class="box-holder">
                    <div class="thumb post-img"><a href="#"> <img src="assets/img/rigth_banner/blog_img_01.jpg" alt="HealthCare"> </a> </div>
                    <div class="post-info mtb_20 ">
                      <h6 class="mb_10 text-uppercase"> <a href="single_blog.html">Unknown printer took a galley book.</a> </h6>
                      <p>Aliquam egestas pellentesque est. Etiam a orci Nulla id enim feugiat ligula ullamcorper scelerisque. Morbi eu luctus nisl.</p>
                      <div class="date-time">
                        <div class="day"> 11</div>
                        <div class="month">Aug</div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="item">
                  <div class="box-holder">
                    <div class="thumb post-img"><a href="#"> <img src="assets/img/rigth_banner/blog_img_01.jpg" alt="HealthCare"> </a></div>
                    <div class="post-info mtb_20 ">
                      <h6 class="mb_10 text-uppercase"> <a href="single_blog.html">Unknown printer took a galley book.</a> </h6>
                      <p>Aliquam egestas pellentesque est. Etiam a orci Nulla id enim feugiat ligula ullamcorper scelerisque. Morbi eu luctus nisl.</p>
                      <div class="date-time">
                        <div class="day"> 11</div>
                        <div class="month">Aug</div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="item">
                  <div class="box-holder">
                    <div class="thumb post-img"><a href="#"> <img src="images/blog/blog_img_03.jpg" alt="HealthCare"> </a></div>
                    <div class="post-info mtb_20 ">
                      <h6 class="mb_10 text-uppercase"> <a href="single_blog.html">Unknown printer took a galley book.</a> </h6>
                      <p>Aliquam egestas pellentesque est. Etiam a orci Nulla id enim feugiat ligula ullamcorper scelerisque. Morbi eu luctus nisl.</p>
                      <div class="date-time">
                        <div class="day"> 11</div>
                        <div class="month">Aug</div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="item">
                  <div class="box-holder">
                    <div class="thumb post-img"><a href="#"> <img src="images/blog/blog_img_04.jpg" alt="HealthCare"> </a></div>
                    <div class="post-info mtb_20 ">
                      <h6 class="mb_10 text-uppercase"> <a href="single_blog.html">Unknown printer took a galley book.</a> </h6>
                      <p>Aliquam egestas pellentesque est. Etiam a orci Nulla id enim feugiat ligula ullamcorper scelerisque. Morbi eu luctus nisl.</p>
                      <div class="date-time">
                        <div class="day"> 11</div>
                        <div class="month">Aug</div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="item">
                  <div class="box-holder">
                    <div class="thumb post-img"><a href="#"> <img src="images/blog/blog_img_05.jpg" alt="HealthCare"> </a></div>
                    <div class="post-info mtb_20 ">
                      <h6 class="mb_10 text-uppercase"> <a href="single_blog.html">Unknown printer took a galley book.</a> </h6>
                      <p>Aliquam egestas pellentesque est. Etiam a orci Nulla id enim feugiat ligula ullamcorper scelerisque. Morbi eu luctus nisl.</p>
                      <div class="date-time">
                        <div class="day"> 11</div>
                        <div class="month">Aug</div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="item">
                  <div class="box-holder">
                    <div class="thumb post-img"><a href="#"> <img src="images/blog/blog_img_06.jpg" alt="HealthCare"> </a></div>
                    <div class="post-info mtb_20 ">
                      <h6 class="mb_10 text-uppercase"> <a href="single_blog.html">Unknown printer took a galley book.</a> </h6>
                      <p>Aliquam egestas pellentesque est. Etiam a orci Nulla id enim feugiat ligula ullamcorper scelerisque. Morbi eu luctus nisl.</p>
                      <div class="date-time">
                        <div class="day"> 11</div>
                        <div class="month">Aug</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- =====  Blog end ===== -->
          </div>
        </div>
      </div>
    </div>
    <!-- =====  CONTAINER END  ===== -->
    <!-- =====  FOOTER START  ===== -->
    <div class="footer pt_60">
      <div class="container">
        <div class="row">
          <div class="col-md-3 footer-block">
            <div class="content_footercms_right">
              <div class="footer-contact">
                <div class="footer-logo mb_40"> <a href="index.html"> <img src="images/footer-logo.png" alt="HealthCare"> </a> </div>
                <ul>
                  <li>B-14 Collins Street West Victoria 2386</li>
                  <li>(+123) 456 789 - (+024) 666 888</li>
                  <li>Contact@yourcompany.com</li>
                </ul>
                <div class="social_icon">
                  <ul>
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-google"></i></a></li>
                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-rss"></i></a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-2 footer-block">
            <h6 class="footer-title ptb_20">Categories</h6>
            <ul>
              <li><a href="#">Medicines</a></li>
              <li><a href="#">Healthcare</a></li>
              <li><a href="#">Mother & Baby</a></li>
              <li><a href="#">Vitamins</a></li>
              <li><a href="#">Toiletries</a></li>
              <li><a href="#">Skincare</a></li>
            </ul>
          </div>
          <div class="col-md-2 footer-block">
            <h6 class="footer-title ptb_20">Information</h6>
            <ul>
              <li><a href="contact.html">Specials</a></li>
              <li><a href="#">New Products</a></li>
              <li><a href="#">Best Sellers</a></li>
              <li><a href="#">Our Stores</a></li>
              <li><a href="#">Contact Us</a></li>
              <li><a href="#">About Us</a></li>
            </ul>
          </div>
          <div class="col-md-2 footer-block">
            <h6 class="footer-title ptb_20">My Account</h6>
            <ul>
              <li><a href="#">Checkout</a></li>
              <li><a href="#">My Account</a></li>
              <li><a href="#">My Orders</a></li>
              <li><a href="#">My Credit Slips</a></li>
              <li><a href="#">My Addresses</a></li>
              <li><a href="#">My Personal Info</a></li>
            </ul>
          </div>
          <div class="col-md-3">
            <h6 class="ptb_20">SIGN UP OUR NEWSLETTER</h6>
            <p class="mt_10 mb_20">For get offers from our favorite brands & get 20% off for next </p>
            <div class="form-group">
              <input class="mb_20" type="text" placeholder="Enter Your Email Address">
              <button class="btn">Subscribe</button>
            </div>
          </div>
        </div>
      </div>
      <div class="footer-bottom mt_60 ptb_10">
        <div class="container">
          <div class="row">
            <div class="col-sm-6">
              <div class="copyright-part">@ 2017 All Rights Reserved HealthCare</div>
            </div>
            <div class="col-sm-6">
              <div class="payment-icon text-right">
                <ul>
                  <li><i class="fa fa-cc-paypal "></i></li>
                  <li><i class="fa fa-cc-stripe"></i></li>
                  <li><i class="fa fa-cc-visa"></i></li>
                  <li><i class="fa fa-cc-discover"></i></li>
                  <li><i class="fa fa-cc-mastercard"></i></li>
                  <li><i class="fa fa-cc-amex"></i></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- =====  FOOTER END  ===== -->
  </div>
  <a id="scrollup">Scroll</a>
  <script src="jquery/jQuery_v3.1.1.min.js"></script>
  <script src="jquery/owl.carousel.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="jquery/jquery.magnific-popup.js"></script>
  <script src="jquery/jquery.firstVisitPopup.js"></script>
  <script src="js/custom.js"></script>
</body>

</html>