<?php
  include ('layout/header.php');
?>
<div class="wrapper">
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Edit User</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            </ol>
          </div>
        </div>
      </div>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6">
            <div class="card card-primary"> 
              <?php 
                if (isset($_SESSION['msg'])) { echo $_SESSION['msg'];
                    session_unset();
                  } 
                  include($_SERVER['DOCUMENT_ROOT'].'/bitm36/project/app/controllers/UserController.php');

                  $id= $_GET['id'];
                  $data['table'] = "users";
                  $data['columns'] = ['id','name', 'email', 'phone', 'address', 'status', 'role', 'created_at'];
                  $data['where']= "id=$id";
                  $data['order_by'] ="id desc";

                  $UserController = UserController::getUserController();
                  $data = $UserController->edit($data);
                  foreach ($data as $key => $value){
              ?>
            </div>
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Update User Info</h3>
              </div>
              <div class="card-body">
                <form action="../../app/controllers/UserController.php" method="post">
                    <input type="hidden" name="update_id" value="<?php echo $value->id ?>">
                    <div class="form-group">
                      <label>Name:</label>
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text"><i class="far fa-file"></i></span>
                        </div>
                        <input type="text" value="<?php echo $value->name ?>" name="name" class="form-control" >
                      </div>
                    </div>
                    <div class="form-group">
                      <label>User Email:</label>
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text"><i class="far fa-file"></i></span>
                        </div>
                        <input type="text" value="<?php echo $value->email ?>"name= "email" class="form-control" >
                      </div>
                    </div>
                    <div class="form-group">
                      <label>Phone:</label>
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text"><i class="far fa-file"></i></span>
                        </div>
                        <input type="text" value="<?php echo $value->phone ?>" name="phone" class="form-control">
                      </div>
                    </div>
                    <div class="form-group">
                      <label>Address:</label>
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text"><i class="far fa-file"></i></span>
                        </div>
                        <input type="text"  value="<?php echo $value->address ?>" name="address" class="form-control" >
                      </div>
                    </div>
                    <div class="form-group">
                      <label>Status:</label>
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text"><i class="far fa-file"></i></span>
                        </div>
                        <select class="form-control" name="status"> 
                          <option value="0"> Select Status </option> 
                          <option value="1"  <?php if($value->status == 1) echo 'selected'?>> Active </option> 
                          <option value="2"  <?php if($value->status == 2) echo 'selected'?>> Inactive </option>
                        </select>
                      </div>
                    </div>
                    <div class="form-group">
                      <label>User Role:</label>
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <span class="input-group-text"><i class="far fa-file"></i></span>
                        </div>
                        <select class="form-control" value="<?php echo $value->role ?>" name="role"> 
                          <option value="0"> Select Role </option>
                          <option value="1">Admin </option>
                          <option value="2" <?php if($value->role == 2) echo 'selected'?>> Supplier </option> 
                          <option value="3" <?php if($value->role == 3) echo 'selected'?>> User </option>
                        </select>
                      </div>
                    </div>
                    <div class= "form-group">
                      <div class="input-group">
                        <input type="submit" name="update" class="btn btn-info" value="Update User">
                      </div>
                    </div>
                </form>
              </div>
              <?php  } ?>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
</div>
<!-- /.content-wrapper -->

<!-- Page script -->
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({
      timePicker: true,
      timePickerIncrement: 30,
      locale: {
        format: 'MM/DD/YYYY hh:mm A'
      }
    })
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //Timepicker
    $('#timepicker').datetimepicker({
      format: 'LT'
    })
    
    //Bootstrap Duallistbox
    $('.duallistbox').bootstrapDualListbox()

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    $('.my-colorpicker2').on('colorpickerChange', function(event) {
      $('.my-colorpicker2 .fa-square').css('color', event.color.toString());
    });

    $("input[data-bootstrap-switch]").each(function(){
      $(this).bootstrapSwitch('state', $(this).prop('checked'));
    });

  })
</script>
<?php
  include ('layout/footer.php');
?>