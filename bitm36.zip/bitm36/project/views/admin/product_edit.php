<?php
  include ('layout/header.php');
?>
<div class="wrapper">
  <?php 

    include($_SERVER['DOCUMENT_ROOT'].'/bitm36/project/app/controllers/admin/ProductController.php');

    $id=$_GET['id'];
    $data['table'] = "products";
    $data['columns'] = ['*'];
    $data['where'] = "id=$id";
    $data['order_by'] = "id desc";

    $ProductController = ProductController::getProductController();
    $product_edit_info= $ProductController->edit($data);              
  ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Edit Product</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="index.php">Home</a></li>
            </ol>
          </div>
        </div>
      </div>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <?php
            if(isset($_SESSION['msg'])){
              echo $_SESSION['msg'];
              session_unset();
            }
          ?>
          <div class="col-md-8">
            <form action="../../app/controllers/admin/ProductController.php" method="post" enctype="multipart/form-data">
              <div class="card card-primary">
                <div class="card-header">
                  <h3 class="card-title">Edit Product</h3>
                </div>
                <div class="card-body">
                  <div class="form-group">
                    <label>Product Name:</label>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="far fa-file"></i></span>
                      </div>
                      <input type="text" class="form-control" name="name" value="<?php echo $product_edit_info[0]->name; ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label>Product Description:</label>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="far fa-file"></i></span>
                      </div>
                      <input type="text" class="form-control" name="description" value="<?php echo $product_edit_info[0]->description; ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label>Product SKUID:</label>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="far fa-file"></i></span>
                      </div>
                      <input type="text" class="form-control" name="sku" value="<?php echo $product_edit_info[0]->sku; ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label>Product Selling Price:</label>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="far fa-file"></i></span>
                      </div>
                      <input type="text" class="form-control" name="selling_price" value="<?php echo $product_edit_info[0]->selling_price; ?>">
                    </div>                
                  </div>
                  <div class="form-group">
                    <label>Product Discount (%):</label>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="far fa-file"></i></span>
                      </div>
                      <input type="text" class="form-control" name="discount" value="<?php echo $product_edit_info[0]->discount; ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label>Product VAT (%):</label>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="far fa-file"></i></span>
                      </div>
                      <input type="text" class="form-control" name="vat" value="<?php echo $product_edit_info[0]->vat; ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label>Product Quantity:</label>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="far fa-file"></i></span>
                      </div>
                      <input type="text" class="form-control" name="stock_qty" value="<?php echo $product_edit_info[0]->stock_qty; ?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label>Product Default Image:</label>

                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="far fa-file"></i></span>
                      </div>
                      <input type="file" name="default_image">
                    </div>
                    <!-- /.input group -->
                    <?php 

                          $data = [];
                          $data['table'] = "product_images";
                          $data['columns'] = ['id', 'product_id','status','image_name' ];
                          $data['where'] = "product_id =".$_GET['id'];
                          $data['order_by'] ="id desc";

                          $ProductController = ProductController::getProductController();
                      $img_data = $ProductController->view($data);

                      foreach ($img_data as $key => $img_data_value) {
                          if($img_data_value->status == 1){
                            $path ="http://localhost:8080/bitm36/project/assetes/default_image/".$img_data_value->image_name;
                            echo "<br>";
                            echo "<img src='".$path."' width='100px'>";
                          }
                          
                      } 
                        ?>
                  </div>
                  <div class="form-group">
                    <label>Product Sub Image:</label>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="far fa-file"></i></span>
                      </div>
                      <input type="file" name="sub_image">
                    </div>
                   <?php

                          $data = [];
                          $data['table'] = "product_images";
                          $data['columns'] = ['id', 'product_id','status','image_name' ];
                          $data['where'] = "product_id =".$_GET['id'];
                          $data['order_by'] ="id desc";

                          $ProductController = ProductController::getProductController();
                      $img_data = $ProductController->view($data);

                      foreach ($img_data as $key => $img_data_value) {
                          if($img_data_value->status == 2){
                            $path ="http://localhost:8080/bitm36/project/assetes/sub_image/".$img_data_value->image_name;
                          }                        }
    
                          echo "<img src='".$path."' width='100px'>";
                        ?>                  
                  </div>
                  <div class="form-group">
                    <label>Product Category:</label>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="far fa-file"></i></span>
                      </div>
                      <select class="form-control" name="pro_cat"> <option> Select Category </option> 
                      <?php
                            
                            $data = [];
                            $data['table'] = "categories";
                            $data['columns'] = ['id','category'];
                            $data['where'] = "";
                            $data['order_by'] = "id desc";

                            $ProductController = ProductController::getProductController();
                            $data = $ProductController->view($data);
                            
                            foreach ($data as $key => $cat_value) {
                              if($product_edit_info[0]->category_id == $cat_value->id){
                                $selected = "selected";
                              }else{
                                $selected = "";
                              }
                              echo "<option value=\"$cat_value->id\" $selected>$cat_value->category</option>";
                            } 
                        ?>
                        </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label>Product Subcategory:</label>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="far fa-file"></i></span>
                      </div>
                      <select class="form-control" name="pro_subcat">  
                        <option> Select Subcategory </option> 
                          <?php
                        
                            $data = [];
                            $data['table'] = "sub_categories";
                            $data['columns'] = ['id','subcategory'];
                            $data['where'] = "";
                            $data['order_by'] = "id desc";

                            $ProductController = ProductController::getProductController();
                            $sub_cat_data = $ProductController->view($data);
                            
                            foreach ($sub_cat_data as $key => $sub_cat_value) {
                              if($product_edit_info[0]->sub_category_id == $sub_cat_value->id){
                                $selected = "selected";
                              }else{
                                $selected = "";
                              }
                              echo "<option value=\"$sub_cat_value->id\" $selected>$sub_cat_value->subcategory</option>";
                            } 
                          ?>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label>Product Brand:</label>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="far fa-file"></i></span>
                      </div>
                      <select class="form-control" name="pro_brand"> <option> Select Brand </option> 
                      <?php
                  
                            $data = [];
                            $data['table'] = "brands";
                            $data['columns'] = ['id','brand'];
                            $data['where'] = "";
                            $data['order_by'] = "id desc";

                            $ProductController = ProductController::getProductController();
                            $brand_data = $ProductController->view($data);
                            
                            foreach ($brand_data as $key => $brand_value) {
                              if($product_edit_info[0]->brand_id == $brand_value->id){
                                $selected = "selected";
                              }else{
                                $selected = "";
                              }
                              echo "<option value=\"$brand_value->id\" $selected>$brand_value->brand</option>";
                            } 
                        ?>
                         </select>
                    </div>
                    </div>
                    <div class="form-group">
                    <label>Product Supplier:</label>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text"><i class="far fa-file"></i></span>
                      </div>
                      <select class="form-control" name="pro_supplier"> <option> Select Supplier </option> 
                      <?php
                  
                            $data = [];

                            $data['table'] = "users";
                            $data['columns'] = ['id','name', 'role'];
                            $data['where'] = "role=2";
                            $data['order_by'] = "id desc";

                            $ProductController = ProductController::getProductController();
                            $supplier_data = $ProductController->view($data);
                            
                            foreach ($supplier_data as $key => $supplier_value) {
                              if($product_edit_info[0]->supplier_id == $supplier_value->id){
                                $selected = "selected";
                              }else{
                                $selected = "";
                              }
                              echo "<option value=\"$supplier_value->id\" $selected>$supplier_value->name</option>";
                            } 
                        ?>
                         </select>
                    </div>
                    </div>
                  <input type="hidden" name="update_id" value="<?php echo $product_edit_info[0]->id; ?>">
                  <div class= "form-group">
                    <div class="input-group">
                      <input type="submit" name="update_product" class="btn btn-info" value="Edit Product">
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>
<!-- /.content-wrapper -->

<!-- Page script -->
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({
      timePicker: true,
      timePickerIncrement: 30,
      locale: {
        format: 'MM/DD/YYYY hh:mm A'
      }
    })
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //Timepicker
    $('#timepicker').datetimepicker({
      format: 'LT'
    })
    
    //Bootstrap Duallistbox
    $('.duallistbox').bootstrapDualListbox()

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    $('.my-colorpicker2').on('colorpickerChange', function(event) {
      $('.my-colorpicker2 .fa-square').css('color', event.color.toString());
    });

    $("input[data-bootstrap-switch]").each(function(){
      $(this).bootstrapSwitch('state', $(this).prop('checked'));
    });

  })
</script>
<?php
  include ('layout/footer.php');
?>