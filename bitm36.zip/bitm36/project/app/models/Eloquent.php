<?php
include($_SERVER['DOCUMENT_ROOT']."/bitm36/project/config/database.php");

class Eloquent extends Database{

	public $Connection;

	public function __construct(){
		$this->Connection = mysqli_connect($this->DBHOST,$this->DBUSER,$this->DBPASSWORD,$this->DBNAME);
	}

	public function insertData($tablename,$columnValues){

		try{
			$sql1 = "INSERT INTO $tablename VALUES ";
			$sql2 = "";

			foreach ($columnValues as $colKey => $columnValue) {
				$columnValue = strtolower($columnValue);
				$sql2 .= "'$columnValue',";
			}
			$sql2 = rtrim($sql2,",");
			$preSql = $sql1.'('.$sql2.')';

			
			$result = $this->Connection->query($preSql);

			if($result){
				return [
					'response' =>'success',
					'last_id'  => $this->Connection->insert_id
				];
			}

		}catch(Exception $e){
			echo $e;
		}

	}

	public function viewData($tablename,$columnValues,$order_by,$where=0){
		try{
			$sql2 = "";
			if($columnValues != "*"){
				foreach ($columnValues as $colKey => $columnValue) {
					$columnValue = strtolower($columnValue);
					$sql2 .= "$columnValue,";
				}
			}

			$sql2 = rtrim($sql2,",");

			$preSql = "SELECT $sql2 FROM $tablename ORDER BY $order_by";
			//print_r($preSql);
			//dii();
			if($where != ""){
				$preSql = "SELECT $sql2 FROM $tablename WHERE $where ORDER BY $order_by";
			}
			//print_r($preSql);
			//dii();
			$result = $this->Connection->query($preSql);

			if($result){
				$value = [];
				while ($data = $result->fetch_object()){
					$value[] =$data;
				};
				return $value;
			}

		}catch(Exception $e){
			echo $e;
		}

	}

	public function updateData($tablename,$columnValues, $order_by, $where=0){
		
		try{
			$sql1 = "UPDATE $tablename SET ";
			$sql2 = "";

			foreach ($columnValues as $colKey => $columnValue) {
				$columnValue = strtolower($columnValue);
				$sql2 .= $colKey."='".$columnValue."',";
			}
			$sql2 = rtrim($sql2,",");
			$preSql = $sql1.$sql2;
			
			if($where != ""){

				$preSql .=" ".$where;
			}
						
			$result = $this->Connection->query($preSql);

			if($result){
				return true;
			}

		}catch(Exception $e){
			echo $e;
		}
	}

	public function delete($table,$where){
		$sql1 =	"DELETE FROM $table ";
		$sql2 =	"WHERE $where";
		$preSql =	$sql1.$sql2;
		
		$result = $this->Connection->query($preSql);
	
		if($result){
			return true;
			}
	}

	public static function getEloquent(){
		$Eloquent = new Eloquent;
		return $Eloquent;
	}

}