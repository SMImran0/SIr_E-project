<?php
  if(!isset($_SESSION)){
    session_start();
  }
  
  include($_SERVER['DOCUMENT_ROOT']."/bitm36/project/app/models/Eloquent.php");
  include($_SERVER['DOCUMENT_ROOT']."/bitm36/project/app/helper/Validation.php");
  include($_SERVER['DOCUMENT_ROOT']."/bitm36/project/config/TimeZone.php");
    
    class BrandController{

    public function create(){

    }

    public function submit($post){
      $brand = Validation::InputValueCheck($post['brand']);
      $error =0;
      $msg= "";

      if(!$brand){
        $error = $error+1;
        $msg .="Brand Name Required <br>";
      }else{
        $brand = $post['brand'];
      }

      if ($error !=0){
        $_SESSION['msg'] =$msg;
        header('location:../../views/admin/brand.php');
      }else {
        $columns = ['', $brand, date("Y-m-d h:i:s")];

        $Eloquent = Eloquent::getEloquent();

        if($Eloquent->insertData("brands",$columns)){
          $_SESSION['msg'] ="Inserted Successfully";
          header('location:../../views/admin/brand.php');
        }else{
          $_SESSION['msg'] = 'Inserted Error';
          header('location:../../views/admin/brand.php');
        }
      }

    }
    
    public function view($info){
      $table = $info['table'];
      $columns = $info['columns'];
      $where = $info['where'];
      $order_by = $info['order_by'];

      $Eloquent = Eloquent::getEloquent();
      
      if($where == ""){
        $output = $Eloquent->viewData($table,$columns,$order_by);
      }else{
        $output = $Eloquent->viewData($table,$columns,$order_by,$where);
      }
      return $output;       
    }

    public function edit($info){
      $table = 'brands';
      $columns = $info['columns'];
      $where = $info['where'];
      $order_by = $info['order_by'];

      $Eloquent = Eloquent::getEloquent();
      
      if($where == ""){
        $output = $Eloquent->viewData($table,$columns,$order_by);
      }else{
        $output = $Eloquent->viewData($table,$columns,$order_by,$where);
      }
      return $output; 
      
    }

    public function update($post){
      $brand = Validation::InputValueCheck($post['brand']);
      $error =0;
      $msg= "";

      if(!$brand){
        $error = $error+1;
        $msg .="Brand Name Required <br>";
      }else{
        $brand = $post['brand'];
      }
        
      
      $id = $post['update_id'];
      if ($error !=0){
        $_SESSION['msg'] =$msg;
        header('location:../../views/admin/brand_edit.php?id='.$id);
      }else {
        $columns = ['brand'=>$brand, 'created_at'=>date("Y-m-d h:i:s")];
        $Eloquent = Eloquent::getEloquent();
        
        $where = "WHERE id = $id";
        $order_by = "id desc";
        if($Eloquent->updateData("brands",$columns,$order_by, $where)){
          $_SESSION['msg'] ="Brand Information Updated Successfully";
          header('location:../../views/admin/brand_view.php');
        }else{
          $_SESSION['msg'] = 'Brand Information Updated Error';
          header('location:../../views/admin/brand_view.php');
        }
      }

    }

    public function delete($id){
      $table = "brands";
      $where = "id=".$id;
      $Eloquent = Eloquent::getEloquent();
      $result = $Eloquent->delete($table,$where);
      if($result){
        $_SESSION['msg'] = "Brand Deleted Successfully";
        header('location:../../views/admin/brand_view.php');
      }

    }
    public static function getBrandController(){
      $BrandController = new BrandController;
      return $BrandController;
    } 
 }
  if (isset($_POST)){
      $getBrandController = BrandController::getBrandController();
      if (isset($_POST['submit'])){       
        $getBrandController->submit($_POST);
      }
      if(isset($_POST['update'])){
        $getBrandController->update($_POST);
      }
    }
    if(isset($_GET['delete'])){
      $getBrandController = BrandController::getBrandController();
      $id = $_GET['delete'];
      $getBrandController->delete($id);
    }
    


?>