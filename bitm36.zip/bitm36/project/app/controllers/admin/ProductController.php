<?php
if(!isset($_SESSION)){
  session_start();
}
  include($_SERVER['DOCUMENT_ROOT']."/bitm36/project/app/models/Eloquent.php");
  Include($_SERVER['DOCUMENT_ROOT']."/bitm36/project/config/TimeZone.php");
    
    
    class ProductController{

      public function create(){

      }

      public function submit($post,$files){
        $name = $post['name'];
        $description = $post['description'];
        $sku = $post['sku'];
        $buying_price = $post['buying_price'];
        $selling_price = $post['selling_price'];
        $discount = $post['discount'];
        $vat = $post['vat'];
        $size = json_encode($post['size']);
        $color = json_encode($post['color']);
        $stock_qty = $post['stock_qty'];
        $pro_cat = $post['pro_cat'];
        $pro_subcat = $post['pro_subcat'];
        $pro_brand=$post['pro_brand'];
        $pro_supplier=$post['pro_supplier'];
       
        $columns = ['', $name, $sku, $description, $buying_price, $selling_price, $discount, $vat,$size,$color, $stock_qty, $pro_cat, $pro_subcat, $pro_brand, $pro_supplier, date("Y-m-d h:i:s"),];
       
        $Eloquent = Eloquent::getEloquent();
            
              if($response = $Eloquent->insertData("products",$columns)){
                
                $product_id = $response['last_id'];

                $_SESSION['msg'] ="Product Inserted Successfully";

                for ($i=0; $i < count($post['color']); $i++) { 
                  $columns = ['',$product_id,$post['color'][$i]]; //changes done
                  $Eloquent->insertData("product_color",$columns);
                }
      
                for ($i=0; $i < count($post['size']); $i++) { 
                  $columns = ['',$product_id,$post['size'][$i]];
                  $Eloquent->insertData("product_size",$columns);
                }

                $default_image = rand(0,999999999).$files['default_image']['name'];
                $sub_image = rand(0,999999999).$files['sub_image']['name'];

                move_uploaded_file($files['default_image']['tmp_name'],$_SERVER['DOCUMENT_ROOT']."/bitm36/project/assetes/default_image/".$default_image);

                move_uploaded_file($files['sub_image']['tmp_name'],$_SERVER['DOCUMENT_ROOT']."/bitm36/project/assetes/sub_image/".$sub_image);

                  $columns = ['', $product_id,1,$default_image];
                  $Eloquent->insertData("product_images",$columns);
                  $columns = ['',$product_id,2,$sub_image];
                  $Eloquent->insertData("product_images",$columns);

                header('location:../../../views/admin/product.php');
              }else{
                $_SESSION['msg'] = 'Product Insert Error';
                header('location:../../../views/admin/product.php');
              }
      }

      public function view($info){
        $table = $info['table'];
        $columns = $info['columns'];
        $where = $info['where'];
        $order_by = $info['order_by'];
  
        $Eloquent = Eloquent::getEloquent();
        
        if($where == ""){
          $output = $Eloquent->viewData($table,$columns,$order_by);
        }else{
          $output = $Eloquent->viewData($table,$columns,$order_by,$where);
        }
  
        return $output;
      }

      public function edit($info){
        $table = $info['table'];
        $columns = $info['columns'];
        $where = $info['where'];
        $order_by = $info['order_by'];
  
        $Eloquent = Eloquent::getEloquent();
        
        if($where == ""){
          $output = $Eloquent->viewData($table,$columns,$order_by);
        }else{
          $output = $Eloquent->viewData($table,$columns,$order_by,$where);
        }
  
        return $output;
      }
    
      public function update($post, $files){

        $name = $post['name'];
        $description = $post['description'];
        $sku = $post['sku'];
        $buying_price = $post['buying_price'];
        $selling_price = $post['selling_price'];
        $discount = $post['discount'];
        $vat = $post['vat'];
        $size = json_encode ($post['size']);
        $color = json_encode ($post['color']);
        $stock_qty = $post['stock_qty'];
        $pro_cat = $post['pro_cat'];
        $pro_subcat = $post['pro_subcat'];
        $pro_brand=$post['pro_brand'];
        $pro_supplier=$post['pro_supplier'];
        $id = $post['update_id'];
       
        $columns = ['name'=>$name,'description'=>$description,'sku'=>$sku,'buying_price'=>$buying_price,'selling_price'=>$selling_price,'discount'=>$discount,'vat'=>$vat, 'size'=>$size, 'color'=>$color,'stock_qty'=>$stock_qty,'category_id'=>$pro_cat,'sub_category_id'=>$pro_subcat,'brand_id'=>$pro_brand, 'supplier_id'=>$pro_supplier, date("Y-m-d h:i:s"),];

        $ProductImageValue = ProductImage::getProductIdToProductImage($id);	

        $Eloquent =Eloquent::getEloquent();

        if ($ProductImageValue[1]->status==1){

          $default_image= rand(0,999999999).$files['default_image']['name'];

          $product_default_image_columns= ['product_id'=>$id, 'status'=>1, 'image_name'=>$default_image];

          $where="";
          $Eloquent->updateData("product_images",$product_default_image_columns,$where);
            unlink($_SERVER['DOCUMENT_ROOT']."/bitm36/project/assetes/default_image/".$ProductImageValue[1]->image_name);
          
        move_uploaded_file($files['default_image']['tmp_name'],$_SERVER['DOCUMENT_ROOT']."/bitm36/project/assetes/default_image/".$default_image);
      }

      if($ProductImageValue[0]->status == 2){

        $sub_image= rand(0,999999999).$files['sub_image']['name'];

          $product_sub_image_columns= ['product_id'=>$id, 'status'=>2, 'image_name'=>$sub_image];

          $where="";
          $Eloquent->updateData("product_images",$product_sub_image_columns,$where);

            unlink($_SERVER['DOCUMENT_ROOT']."/bitm36/project/assetes/sub_image/".$ProductImageValue[0]->image_name);
          
        move_uploaded_file($files['sub_image']['tmp_name'],$_SERVER['DOCUMENT_ROOT']."/bitm36/project/assetes/sub_image/".$sub_image);

      }

        $where = "WHERE ID = $id";

        
        if($Eloquent->updateData("products",$columns,$where)){
          $_SESSION['msg'] = "Product Updated Successfully";
          header('location:../../../views/admin/product_view.php');
        }else{
          $_SESSION['msg'] = "Product Update Error";
          header('location:../../../views/admin/product_view.php');
        }

      }
	
		
        public function delete($id){
          $table = "products";
          $where = "id=".$id;
          $Eloquent = Eloquent::getEloquent();
          $result = $Eloquent->delete($table,$where);
          if($result){
            $_SESSION['msg'] = "Products Deleted Successfully";
            header('location:../../../views/admin/product_view.php');
          }

          $table = "product_images";
          $where = "id=".$id;
          $Eloquent = Eloquent::getEloquent();
          $result = $Eloquent->delete($table,$where);
          if($result){
            $_SESSION['msg'] = "Products Deleted Successfully";
            header('location:../../../views/admin/product_view.php');
          }
      }
      
      public static function getProductController(){
        $ProductController = new ProductController;
        return $ProductController;
      }
   

    }
    
    if(isset($_POST)){
      $getProductController = ProductController::getProductController();
      if(isset($_POST['submit'])){
        $getProductController->submit($_POST,$_FILES);
      }
      if(isset($_POST['update'])){
        $getProductController->update($_POST,$_FILES);
      }
      if(isset($_POST['update_product'])){
        $getProductController->update($_POST,$_FILES);
      }
    }
    if(isset($_GET['delete'])){
      $getProductController = ProductController::getProductController();
      $id = $_GET['delete'];
      $getProductController->delete($id);
    }

?>