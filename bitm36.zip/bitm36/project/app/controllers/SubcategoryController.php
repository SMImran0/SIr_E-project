<?php
  if(!isset($_SESSION)){
    session_start();
  }
  
  include($_SERVER['DOCUMENT_ROOT']."/bitm36/project/app/models/Eloquent.php");
  include($_SERVER['DOCUMENT_ROOT']."/bitm36//project/app/helper/Validation.php");
  include($_SERVER['DOCUMENT_ROOT']."/bitm36//project/config/TimeZone.php");
    
    class SubcategoryController{

    public function create(){

    }

    public function submit($post){
      $subcategory = Validation::InputValueCheck($post['subcategory']);
      $error =0;
      $msg= "";

      if(!$subcategory){
        $error = $error+1;
        $msg .="Subcategory Name Required <br>";
      }else{
        $subcategory = $post['subcategory'];
      }

      if ($error !=0){
        $_SESSION['msg'] =$msg;
        header('location:../../views/admin/subcategory.php');
      }else {
        $columns = ['', $subcategory, date("Y-m-d h:i:s")];

        $Eloquent = Eloquent::getEloquent();

        if($Eloquent->insertData("sub_categories",$columns)){
          $_SESSION['msg'] ="Inserted Successfully";
          header('location:../../views/admin/subcategory.php');
        }else{
          $_SESSION['msg'] = 'Inserted Error';
          header('location:../../views/admin/subcategory.php');
        }
      }

    }
    
    public function view($info){
      $table = $info['table'];
      $columns = $info['columns'];
      $where = $info['where'];
      $order_by = $info['order_by'];

      $Eloquent = Eloquent::getEloquent();
      
      if($where == ""){
        $output = $Eloquent->viewData($table,$columns,$order_by);
      }else{
        $output = $Eloquent->viewData($table,$columns,$order_by,$where);
      }
      return $output;       
    }

    public function edit($info){
      $table = 'sub_categories';
      $columns = $info['columns'];
      $where = $info['where'];
      $order_by = $info['order_by'];

      $Eloquent = Eloquent::getEloquent();
      
      if($where == ""){
        $output = $Eloquent->viewData($table,$columns,$order_by);
      }else{
        $output = $Eloquent->viewData($table,$columns,$order_by,$where);
      }
      return $output; 
      
    }

    public function update($post){
      $subcategory = Validation::InputValueCheck($post['subcategory']);
      $error =0;
      $msg= "";

      if(!$subcategory){
        $error = $error+1;
        $msg .="Subcategory Name Required <br>";
      }else{
        $subcategory = $post['subcategory'];
      }
        
      
      $id = $post['update_id'];
      if ($error !=0){
        $_SESSION['msg'] =$msg;
        header('location:../../views/admin/subcategory_edit.php?id='.$id);
      }else {
        $columns = ['subcategory'=>$subcategory, 'created_at'=>date("Y-m-d h:i:s")];
        $Eloquent = Eloquent::getEloquent();
        
        $where = "WHERE id = $id";
        $order_by = "id desc";
        if($Eloquent->updateData("sub_categories",$columns,$order_by, $where)){
          $_SESSION['msg'] ="Sub Category Information Updated Successfully";
          header('location:../../views/admin/subcategory_view.php');
        }else{
          $_SESSION['msg'] = 'Sub Category Information Updated Error';
          header('location:../../views/admin/subcategory_view.php');
        }
      }

    }

    public function delete($id){
      $table = "sub_categories";
      $where = "id=".$id;
      $Eloquent = Eloquent::getEloquent();
      $result = $Eloquent->delete($table,$where);
      if($result){
        $_SESSION['msg'] = "Sub Category Deleted Successfully";
        header('location:../../views/admin/subcategory_view.php');
      }

    }
    public static function getSubcategoryController(){
      $SubcategoryController = new SubcategoryController;
      return $SubcategoryController;
    } 
 }
  if (isset($_POST)){
      $getSubcategoryController = SubcategoryController::getSubcategoryController();
      if (isset($_POST['submit'])){       
        $getSubcategoryController->submit($_POST);
      }
      if(isset($_POST['update'])){
        $getSubcategoryController->update($_POST);
      }
    }
    if(isset($_GET['delete'])){
      $getSubcategoryController = SubcategoryController::getSubcategoryController();
      $id = $_GET['delete'];
      $getSubcategoryController->delete($id);
    }
    
?>