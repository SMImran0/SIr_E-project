<?php 
if(!isset($_SESSION)){
  session_start();
}
include($_SERVER['DOCUMENT_ROOT']."/bitm36/project/app/models/Eloquent.php");

  class LoginController {

    function LoginCheck($email,$password){

      $Eloquent = Eloquent::getEloquent();
      $table = "users";
      $columns = ['name','email','passwords','role'];
			$where = "email ='".$email."' && passwords='".md5($password)."'";
			$order_by = "id asc";
      $output = $Eloquent->viewData($table,$columns,$order_by,$where);
      
      if(count($output) ==1){

				foreach ($output as $key => $value) {
					$_SESSION['logged_email'] = $value->email;
					$_SESSION['logged_name'] = $value->name;
					$_SESSION['logged_role'] = $value->role;
				}
				if($_SESSION['logged_role'] == 1){
					header('location:http://localhost:8080/bitm36/project/views/admin/index.php');
				}elseif($_SESSION['logged_role'] == 2){
					header('location:http://localhost:8080/bitm36/project/views/supplier/index.php');
				}elseif($_SESSION['logged_role'] == 3){
					header('location:http://localhost:8080/bitm36/project/views/FRO/index.php');
				}
      }else{  
        header('location:http://localhost:8080/bitm36/project/login.html'); 
      }

    }
    public static function GetLoginController(){
      $LoginController = new LoginController;
      return $LoginController;
    }

  }
  if(isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    $LoginController = LoginController::GetLoginController();
    $LoginController->LoginCheck($email,$password);

  }

?>