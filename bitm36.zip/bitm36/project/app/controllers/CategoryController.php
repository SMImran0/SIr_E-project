<?php
  if(!isset($_SESSION)){
    session_start();
  }
  
  include($_SERVER['DOCUMENT_ROOT']."/bitm36/project/app/models/Eloquent.php");
  include($_SERVER['DOCUMENT_ROOT']."/bitm36/project/app/helper/Validation.php");
  include($_SERVER['DOCUMENT_ROOT']."/bitm36/project/config/TimeZone.php");
    
    class CategoryController{

    public function create(){

    }

    public function submit($post){
      $category = Validation::InputValueCheck($post['category']);
      $error =0;
      $msg= "";

      if(!$category){
        $error = $error+1;
        $msg .="Category Name Required <br>";
      }else{
        $category = $post['category'];
      }

      if ($error !=0){
        $_SESSION['msg'] =$msg;
        header('location:../../views/admin/category.php');
      }else {
        $columns = ['', $category, date("Y-m-d h:i:s")];

        $Eloquent = Eloquent::getEloquent();

        if($Eloquent->insertData("categories",$columns)){
          $_SESSION['msg'] ="Inserted Successfully";
          header('location:../../views/admin/category_view.php');
        }else{
          $_SESSION['msg'] = 'Inserted Error';
          header('location:../../views/admin/category.php');
        }
      }

    }
    
    public function view($info){
      $table = $info['table'];
      $columns = $info['columns'];
      $where = $info['where'];
      $order_by = $info['order_by'];

      $Eloquent = Eloquent::getEloquent();
      
      if($where == ""){
        $output = $Eloquent->viewData($table,$columns,$order_by);
      }else{
        $output = $Eloquent->viewData($table,$columns,$order_by,$where);
      }
      return $output;       
    }

    public function edit($info){
      $table = 'categories';
      $columns = $info['columns'];
      $where = $info['where'];
      $order_by = $info['order_by'];

      $Eloquent = Eloquent::getEloquent();
      
      if($where == ""){
        $output = $Eloquent->viewData($table,$columns,$order_by);
      }else{
        $output = $Eloquent->viewData($table,$columns,$order_by,$where);
      }
      return $output; 
      
    }

    public function update($post){
      $category = Validation::InputValueCheck($post['category']);
      $error =0;
      $msg= "";

      if(!$category){
        $error = $error+1;
        $msg .="Category Name Required <br>";
      }else{
        $category = $post['category'];
      }
        
      
      $id = $post['update_id'];
      if ($error !=0){
        $_SESSION['msg'] =$msg;
        header('location:../../views/admin/category_edit.php?id='.$id);
      }else {
        $columns = ['category'=>$category, 'created_at'=>date("Y-m-d h:i:s")];
        $Eloquent = Eloquent::getEloquent();
        
        $where = "WHERE id = $id";
        $order_by = "id desc";
        if($Eloquent->updateData("categories",$columns,$order_by, $where)){
          $_SESSION['msg'] ="Category Information Updated Successfully";
          header('location:../../views/admin/category_view.php');
        }else{
          $_SESSION['msg'] = 'Category Information Updated Error';
          header('location:../../views/admin/category_view.php');
        }
      }

    }

    public function delete($id){
      $table = "categories";
      $where = "id=".$id;
      $Eloquent = Eloquent::getEloquent();
      $result = $Eloquent->delete($table,$where);
      if($result){
        $_SESSION['msg'] = "Category Deleted Successfully";
        header('location:../../views/admin/category_view.php');
      }

    }
    public static function getCategoryController(){
      $CategoryController = new CategoryController;
      return $CategoryController;
    } 
 }
  if (isset($_POST)){
      $getCategoryController = CategoryController::getCategoryController();
      if (isset($_POST['submit'])){       
        $getCategoryController->submit($_POST);
      }
      if(isset($_POST['update'])){
        $getCategoryController->update($_POST);
      }
    }
    if(isset($_GET['delete'])){
      $getCategoryController = CategoryController::getCategoryController();
      $id = $_GET['delete'];
      $getCategoryController->delete($id);
    }
    


?>