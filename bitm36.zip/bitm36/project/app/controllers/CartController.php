<?php
  if(!isset($_SESSION)){
    session_start();
  }
  
  include($_SERVER['DOCUMENT_ROOT']."/bitm36/project/app/models/Eloquent.php");
    
    class CartController{

    public function create($post){
     // declair add to cart 
      #print_r($post);
      #die();
     $add_to_cart = [];
     
     // assign product name in add to cart array

     $add_to_cart['pro_name']   = $post['pro_name'];
     $add_to_cart['pro_prize']  = $post['pro_prize'];
     $add_to_cart['pro_id']     = $post['pro_id'];
     $add_to_cart['pro_qty']    = $post['pro_qty'];
     $add_to_cart['pro_image']  = $post['pro_image'];
     $add_to_cart['pro_size']  = $post['pro_size'];
     $add_to_cart['pro_color']  = $post['pro_color'];
     $add_to_cart['pro_sku']  = $post['pro_sku'];
   
       // check any thing in cart
       if(isset($_SESSION['cart_item'])){

            // match alrady exits or nots

            foreach ($_SESSION['cart_item'] as $key => $value) {
              if($value['pro_id'] == $post['pro_id']){
                $exists = true; 
                $_SESSION['cart_item'][$key]['pro_qty']++;
              }else{
                $exists = false;
              }
            }

            // if not exists then add 
            if(!isset($exists) || $exists == false){
              echo "match not found";
              $_SESSION['cart_item'][] = $add_to_cart;
            }
            
       }else{
              $_SESSION['cart_item'][] = $add_to_cart;
       }

        header('location:http://localhost:8080/bitm36/project/views/Fro/cart_page.php');
    }

    public function coupon($post){
      $coupon = ['ABC10'=>10,'ABC20'=>20,'ABC30'=>30];

      foreach($coupon as $key => $value) {
        if($key == $post['coupon_value']){
          $_SESSION['coupon'] = $value;
        }
      }
      header('location:http://localhost:8080/bitm36/project/views/Fro/cart_page.php');
    }
    
}


    if (isset($_POST)){
        if (isset($_POST['add_to_cart'])){       
          CartController::create($_POST);
        }
        if (isset($_POST['coupon'])){       
          CartController::coupon($_POST);
        }
    }

?>