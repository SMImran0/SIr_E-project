<?php
if(!isset($_SESSION)){
  session_start();
}
    include($_SERVER['DOCUMENT_ROOT']."/bitm36/project/app/models/Eloquent.php");
    include($_SERVER['DOCUMENT_ROOT']."/bitm36/project/app/helper/Validation.php");
    include($_SERVER['DOCUMENT_ROOT']."/bitm36/project/config/TimeZone.php");
    
    
    class OrderController{

      public function create(){

      }

      public function view($info){
        $table = $info['table'];
        $columns = $info['columns'];
        $where = $info['where'];
        $order_by = $info['order_by'];

        $Eloquent = Eloquent::getEloquent();
        
        if($where == ""){
          $output = $Eloquent->viewData($table,$columns,$order_by);
        }else{
          $output = $Eloquent->viewData($table,$columns,$order_by,$where);
        }
        return $output;       
      }

      public function edit($info){
        $table = 'users';
        $columns = $info['columns'];
        $where = $info['where'];
        $order_by = $info['order_by'];

        $Eloquent = Eloquent::getEloquent();
      
        if($where == ""){
          $output = $Eloquent->viewData($table,$columns,$order_by);
        }else{     
          $output = $Eloquent->viewData($table,$columns,$order_by,$where);
        }
        return $output; 
      }
    
 
      public function delete($id){
        $table = "order_details";
        $where = "id=".$id;
        $Eloquent = Eloquent::getEloquent();
        $result = $Eloquent->delete($table,$where);
        if($result){
          $_SESSION['msg'] = "Order Deleted Successfully";
          header('location:../../views/admin/order.php');
        }
      }
      public static function getOrderController(){
        $OrderController = new OrderController;
        return $OrderController;
      } 
   }
 
    if(isset($_GET['delete'])){
      $getOrderController = OrderController::getOrderController();
      $id = $_GET['delete'];
      $getOrderController->delete($id);
    }
    

?>