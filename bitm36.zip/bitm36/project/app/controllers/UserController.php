<?php
if(!isset($_SESSION)){
  session_start();
}
    include($_SERVER['DOCUMENT_ROOT']."/bitm36/project/app/models/Eloquent.php");
    include($_SERVER['DOCUMENT_ROOT']."/bitm36/project/app/helper/Validation.php");
    include($_SERVER['DOCUMENT_ROOT']."/bitm36/project/config/TimeZone.php");
    
    
    class UserController{

      public function create(){

      }

      public function submit($post){
        $name = Validation::InputValueCheck($post['name']);
        $email = Validation::InputValueCheck($post['email']);
        $passwords = Validation::InputValueCheck($post['passwords']);
        $phone = Validation::InputValueCheck($post['phone']);
        $address = Validation::InputValueCheck($post['address']);
        $status = Validation::InputValueCheck($post['status']);
        $role = Validation::InputValueCheck($post['role']);
        $error =0;
        $msg= "";

        if(!$name){
          $error = $error+1;
          $msg .="Name Required <br>";
          }else{
            $name = $post['name'];
          }
          
        if(!$email){
          $error = $error+1;
          $msg .= "Email Required <br>";
          }else{
            $email = $post['email'];
          }
      
        if(!$passwords){
            $error = $error+1;
            $msg .= "Password Required <br>";
          }else{
            $passwords = Validation::InputPasswordEnc($post['passwords']);
          }
          
        if(!$phone){
          $error = $error+1;
          $msg .="Phone Number Required <br>";
          }else {
            $phone = $post['phone'];
          }

        if(!$address){
          $error = $error+1;
          $msg .="Address Required<br>";
          }else {
            $address = $post['address'];
          }

        if(!$status){
          $error = $error+1;
          $msg .="Status Required<br>";
        }else {
          $status = $post['status'];
        }

        if(!$role){
          $error = $error+1;
          $msg .="Role Required <br>";
        }else {
          $role = $post['role'];
        }

        if ($error !=0){
          $_SESSION['msg'] =$msg;
          header('location:../../views/admin/user.php');
          }else {
            $columns = ['', $name, $email, $passwords, $phone, $address, $status, $role, 0,date("Y-m-d h:i:s")];
            $Eloquent = Eloquent::getEloquent();
            
              if($Eloquent->insertData("users",$columns)){
                $_SESSION['msg'] ="Inserted Successfully";
                header('location:../../views/admin/user.php');
              }else{
                $_SESSION['msg'] = 'Inserted Error';
                header('location:../../views/admin/user.php');
              }
        }

      }

      public function view($info){
        $table = $info['table'];
        $columns = $info['columns'];
        $where = $info['where'];
        $order_by = $info['order_by'];

        $Eloquent = Eloquent::getEloquent();
        
        if($where == ""){
          $output = $Eloquent->viewData($table,$columns,$order_by);
        }else{
          $output = $Eloquent->viewData($table,$columns,$order_by,$where);
        }
        return $output;       
      }

      public function edit($info){
        $table = 'users';
        $columns = $info['columns'];
        $where = $info['where'];
        $order_by = $info['order_by'];

        $Eloquent = Eloquent::getEloquent();
      
        if($where == ""){
          $output = $Eloquent->viewData($table,$columns,$order_by);
        }else{     
          $output = $Eloquent->viewData($table,$columns,$order_by,$where);
        }
        return $output; 
      }
    
      public function update($post){
        $name = Validation::InputValueCheck($post['name']);
        $email = Validation::InputValueCheck($post['email']);
        $phone = Validation::InputValueCheck($post['phone']);
        $address = Validation::InputValueCheck($post['address']);
        $status = Validation::InputValueCheck($post['status']);
        $role = Validation::InputValueCheck($post['role']);
        $error =0;
        $msg= "";

        if(!$name){
          $error = $error+1;
          $msg .="Name Required <br>";
        }else{
          $name = $post['name'];
        }
          
          if(!$email){
            $error = $error+1;
            $msg .= "Email Required <br>";
          }else{
            $email = $post['email'];
          }

        if(!$phone){
          $error = $error+1;
          $msg .="Phone Number Required <br>";
        }else {
          $phone = $post['phone'];
        }

        if(!$address){
          $error = $error+1;
          $msg .="Address Required<br>";
        }else {
          $address = $post['address'];
        }

        if(!$status){
          $error = $error+1;
          $msg .="Status Required<br>";
        }else {
          $status = $post['status'];
        }

        if(!$role){
          $error = $error+1;
          $msg .="Role Required <br>";
        }else {
          $role = $post['role'];
        }
        
        $id = $post['update_id'];
        if ($error !=0){
          $_SESSION['msg'] =$msg;
          header('location:../../views/admin/user_edit.php?id='.$id);
        }else {
          $columns = ['name'=>$name, 'email'=>$email, 'phone'=>$phone, 'address'=> $address, 'status'=>$status, 'role'=>$role, 'email_verified'=>0,'created_at'=>date("Y-m-d h:i:s")];
          $Eloquent = Eloquent::getEloquent();
          
          $where = "WHERE id = $id";
          $order_by = "id desc";
          if($Eloquent->updateData("users",$columns,$order_by,$where)){
            $_SESSION['msg'] ="User Informatin Updated Successfully";
            header('location:../../views/admin/user_view.php');
          }else{
            $_SESSION['msg'] = 'User Informatin Updated Error';
            header('location:../../views/admin/user_view.php');
          }
        }

      }

      public function delete($id){
        $table = "users";
        $where = "id=".$id;
        $Eloquent = Eloquent::getEloquent();
        $result = $Eloquent->delete($table,$where);
        if($result){
          $_SESSION['msg'] = "User Deleted Successfully";
          header('location:../../views/admin/user_view.php');
        }
      }
      public static function getUserController(){
        $UserController = new UserController;
        return $UserController;
      } 
   }
  if (isset($_POST)){
      $getUserController = UserController::getUserController();
      if (isset($_POST['submit'])){       
        $getUserController->submit($_POST);
      }
      if(isset($_POST['update'])){
        $getUserController->update($_POST);
      }
    }
    if(isset($_GET['delete'])){
      $getUserController = UserController::getUserController();
      $id = $_GET['delete'];
      $getUserController->delete($id);
    }
    

?>