<?php


  class Validation
  {
    public static function InputValueCheck($data)
    {
      if ($data != ""){
        return true;
      }else{
        return false;
      }
    }
      public static function  InputEmailCheck($data)
        {
          if (filter_var($data, FILTER_VALIDATE_EMAIL)){
            return true;
          }else{
            return false;
          }
    
        }
    
        public static function InputPasswordEnc($data){
    
          $data = md5($data);
          return $data;
          }
    
      }
    
    
    ?>

  