<?php

    include_once($_SERVER['DOCUMENT_ROOT']."/bitm36/project/app/models/Eloquent.php");
    
    class GetSize {

        public static function getIdToSizeName($id){
            
            $table = "sizes";
            $columns = ['id','name'];
            $where = "id=$id";
            $order_by = "id desc";
            $Eloquent = Eloquent::getEloquent();

            if($where == ""){
				$output = $Eloquent->viewData($table,$columns,$order_by);
			}else{
				$output = $Eloquent->viewData($table,$columns,$order_by,$where);
			}
            return $output;

        }

    }


?>